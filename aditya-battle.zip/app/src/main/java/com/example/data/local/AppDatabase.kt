package com.example.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String,
    val entryFeePaise: Long,
    val maxSlots: Int,
    val filledSlots: Int,
    val matchFormat: String,
    val mapName: String,
    val scheduledTimeEpoch: Long,
    val status: String,
    val roomId: String,
    val roomPassword: String,
    val roomReleaseTime: String,
    val description: String,
    val rulesJson: String,
    val killPointRewardPaise: Long,
    val bannerResId: Int?,
    val difficulty: String = "NORMAL",
    val isJoined: Boolean = false
)

@Entity(tableName = "game_maps")
data class GameMapEntity(
    @PrimaryKey val id: String,
    val name: String,
    val modeCategory: String,
    val roomType: String,
    val isEnabled: Boolean,
    val supportedFormatsJson: String,
    val minPlayers: Int,
    val maxPlayers: Int,
    val description: String,
    val bannerResId: Int?
)

@Entity(tableName = "game_modes")
data class GameModeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val parentCategory: String,
    val isRanked: Boolean,
    val defaultMatchFormat: String,
    val isEnabled: Boolean,
    val description: String
)

@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val type: String,
    val amountPaise: Long,
    val balanceAfterPaise: Long,
    val description: String,
    val referenceId: String,
    val status: String,
    val timestamp: Long,
    val tournamentTitle: String?
)

@Entity(tableName = "participants")
data class ParticipantEntity(
    @PrimaryKey val id: String,
    val tournamentId: String,
    val userId: String,
    val username: String,
    val inGameName: String,
    val inGameId: String,
    val entryFeePaise: Long,
    val transactionId: String,
    val slotNumber: Int,
    val joinedAt: Long
)

@Entity(tableName = "daily_tasks")
data class DailyTaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val rewardCoins: Long,
    val currentProgress: Int,
    val maxProgress: Int,
    val isClaimed: Boolean
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val type: String,
    val timestamp: Long,
    val isRead: Boolean
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val adminName: String,
    val action: String,
    val target: String,
    val details: String,
    val timestamp: Long
)

@Dao
interface TournamentDao {
    @Query("SELECT * FROM tournaments ORDER BY scheduledTimeEpoch ASC")
    fun getAllTournaments(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments WHERE id = :id")
    suspend fun getTournamentById(id: String): TournamentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournaments(tournaments: List<TournamentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity)

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Query("UPDATE tournaments SET filledSlots = filledSlots + 1, isJoined = 1 WHERE id = :id")
    suspend fun markJoined(id: String)
}

@Dao
interface GameMapDao {
    @Query("SELECT * FROM game_maps")
    fun getAllMaps(): Flow<List<GameMapEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaps(maps: List<GameMapEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMap(map: GameMapEntity)

    @Update
    suspend fun updateMap(map: GameMapEntity)

    @Query("DELETE FROM game_maps WHERE id = :id")
    suspend fun deleteMap(id: String)
}

@Dao
interface GameModeDao {
    @Query("SELECT * FROM game_modes")
    fun getAllModes(): Flow<List<GameModeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModes(modes: List<GameModeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMode(mode: GameModeEntity)

    @Update
    suspend fun updateMode(mode: GameModeEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<WalletTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: WalletTransactionEntity)
}

@Dao
interface ParticipantDao {
    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId ORDER BY slotNumber ASC")
    fun getParticipantsForTournament(tournamentId: String): Flow<List<ParticipantEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParticipant(participant: ParticipantEntity)

    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId AND userId = :userId LIMIT 1")
    suspend fun getParticipant(tournamentId: String, userId: String): ParticipantEntity?
}

@Dao
interface DailyTaskDao {
    @Query("SELECT * FROM daily_tasks")
    fun getAllTasks(): Flow<List<DailyTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<DailyTaskEntity>)

    @Update
    suspend fun updateTask(task: DailyTaskEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}

@Database(
    entities = [
        TournamentEntity::class,
        GameMapEntity::class,
        GameModeEntity::class,
        WalletTransactionEntity::class,
        ParticipantEntity::class,
        DailyTaskEntity::class,
        NotificationEntity::class,
        AuditLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tournamentDao(): TournamentDao
    abstract fun gameMapDao(): GameMapDao
    abstract fun gameModeDao(): GameModeDao
    abstract fun transactionDao(): TransactionDao
    abstract fun participantDao(): ParticipantDao
    abstract fun dailyTaskDao(): DailyTaskDao
    abstract fun notificationDao(): NotificationDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aditya_battle_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

