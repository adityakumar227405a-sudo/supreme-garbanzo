package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.data.local.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class EsportsRepository(private val context: Context) {

    private val database = AppDatabase.getDatabase(context)
    private val scope = CoroutineScope(Dispatchers.IO)
    private val joinMutex = Mutex()

    // Current User Session State
    private val _currentUser = MutableStateFlow<UserProfile?>(
        UserProfile(
            id = "user_aditya_01",
            username = "AdityaWarrior",
            email = "aditya.esports@battle.in",
            mobileNumber = "+91 98765 43210",
            inGameName = "ShadowHunter",
            inGameId = "84920481",
            role = UserRole.USER,
            kycStatus = KycStatus.VERIFIED,
            referralCode = "ADITYA99",
            totalTournaments = 14,
            totalWins = 5,
            totalKills = 76
        )
    )
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    // Real Wallet State
    private val _walletState = MutableStateFlow(
        WalletState(
            userId = "user_aditya_01",
            depositBalancePaise = 50000L, // ₹500
            winningWithdrawablePaise = 150000L, // ₹1,500
            coinBalance = 1200L
        )
    )
    val walletState: StateFlow<WalletState> = _walletState.asStateFlow()

    // In-memory + Local Database Tournaments
    private val _tournaments = MutableStateFlow<List<TournamentItem>>(emptyList())
    val tournaments: StateFlow<List<TournamentItem>> = _tournaments.asStateFlow()

    // Transactions list
    private val _transactions = MutableStateFlow<List<WalletTransactionRecord>>(emptyList())
    val transactions: StateFlow<List<WalletTransactionRecord>> = _transactions.asStateFlow()

    // Daily Tasks
    private val _dailyTasks = MutableStateFlow<List<DailyTaskItem>>(emptyList())
    val dailyTasks: StateFlow<List<DailyTaskItem>> = _dailyTasks.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    // Match Results for finalized / live matches
    private val _matchResults = MutableStateFlow<Map<String, List<MatchResultRecord>>>(emptyMap())
    val matchResults: StateFlow<Map<String, List<MatchResultRecord>>> = _matchResults.asStateFlow()

    // All Users for Admin management
    private val _allUsers = MutableStateFlow<List<UserProfile>>(emptyList())
    val allUsers: StateFlow<List<UserProfile>> = _allUsers.asStateFlow()

    // Audit logs
    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    // Configurable Game Modes
    private val _gameModes = MutableStateFlow<List<ConfigurableGameMode>>(emptyList())
    val gameModes: StateFlow<List<ConfigurableGameMode>> = _gameModes.asStateFlow()

    // Configurable Game Maps
    private val _gameMaps = MutableStateFlow<List<ConfigurableGameMap>>(emptyList())
    val gameMaps: StateFlow<List<ConfigurableGameMap>> = _gameMaps.asStateFlow()

    // Home Banners
    val banners = listOf(
        HomeBanner(
            id = "b0",
            title = "Aditya Battle Esports Arena",
            subtitle = "Official Host & Championship Matches • Instant Payouts",
            tag = "FOUNDER & HOST",
            imageRes = R.drawable.banner_aditya_founder_1787621660204,
            targetCategory = null
        ),
        HomeBanner(
            id = "b1",
            title = "Battle Royale Mega Clash",
            subtitle = "₹24,000 Prize Pool • Bermuda Map",
            tag = "HOT FEATURED",
            imageRes = R.drawable.banner_battle_royale_1787620022121,
            targetCategory = TournamentCategory.BATTLE_ROYALE
        ),
        HomeBanner(
            id = "b2",
            title = "Clash Squad Pro 4v4",
            subtitle = "Guaranteed Instant Rewards • 80% Payout",
            tag = "DAILY PRO",
            imageRes = R.drawable.banner_clash_squad_1787620035781,
            targetCategory = TournamentCategory.CLASH_SQUAD
        )
    )

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val initialTournaments = listOf(
            // --- Small / Pocket Tournaments (₹5, ₹10, ₹20) ---
            TournamentItem(
                id = "tour_easy_5",
                title = "₹5 Easy Starter Solo Cup",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 500L, // ₹5
                maxSlots = 48,
                filledSlots = 28,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.CLASSIC_BERMUDA,
                scheduledTimeEpoch = System.currentTimeMillis() + 1800000L, // 30 mins
                status = TournamentStatus.OPEN,
                roomId = "8819205",
                roomPassword = "EASY5",
                roomReleaseTime = "10 mins before match",
                description = "Chhota tournament for beginners & casual warriors! Just ₹5 entry with guaranteed 85% prize pool payout + ₹2 per kill rewards.",
                rules = listOf(
                    "Open to all beginner and casual players.",
                    "No emulators or external triggers.",
                    "Room credentials released 10 mins before match."
                ),
                difficulty = TournamentDifficulty.EASY,
                customBannerRes = R.drawable.banner_battle_royale_1787620022121
            ),
            TournamentItem(
                id = "tour_easy_lw_5",
                title = "₹5 Easy 1v1 Lone Wolf",
                category = TournamentCategory.LONE_WOLF,
                entryFeePaise = 500L, // ₹5
                maxSlots = 16,
                filledSlots = 11,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.CUSTOM_MAP,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 1, // 1 hour
                status = TournamentStatus.OPEN,
                roomId = "5529184",
                roomPassword = "WOLF5",
                roomReleaseTime = "10 mins before match",
                description = "Quick 1v1 mechanical duel for ₹5. Instant match settlement with 85% prize pool distribution.",
                rules = listOf(
                    "Pure 1v1 duel format, first to 5 rounds wins.",
                    "Headshot only mode enabled."
                ),
                difficulty = TournamentDifficulty.EASY
            ),
            TournamentItem(
                id = "tour_normal_10",
                title = "₹10 Normal Clash Squad 4v4",
                category = TournamentCategory.CLASH_SQUAD,
                entryFeePaise = 1000L, // ₹10
                maxSlots = 16,
                filledSlots = 12,
                matchFormat = MatchFormat.CLASH_4V4,
                mapName = RoomType.CUSTOM_MAP,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 2, // 2 hours
                status = TournamentStatus.OPEN,
                roomId = "6639101",
                roomPassword = "NORM10",
                roomReleaseTime = "15 mins before match",
                description = "Standard ₹10 clash squad match for tactical 4-player teams. High action and 85% cash prize distribution.",
                rules = listOf(
                    "Standard esports clash rules: No Grenade launcher.",
                    "Character skills enabled. Gun attributes off."
                ),
                difficulty = TournamentDifficulty.NORMAL,
                customBannerRes = R.drawable.banner_clash_squad_1787620035781
            ),
            TournamentItem(
                id = "tour_easy_10",
                title = "₹10 Easy Bermuda Rush",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 1000L, // ₹10
                maxSlots = 48,
                filledSlots = 35,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.CLASSIC_BERMUDA,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 3, // 3 hours
                status = TournamentStatus.OPEN,
                roomId = "7718290",
                roomPassword = "RUSH10",
                roomReleaseTime = "15 mins before match",
                description = "Popular ₹10 solo battle royale. Safe zone shrinks quickly for intense action.",
                rules = listOf(
                    "Solo play only. Cross-teaming results in disqualification.",
                    "Top 8 rankers receive guaranteed prize pool."
                ),
                difficulty = TournamentDifficulty.EASY
            ),
            TournamentItem(
                id = "tour_medium_20",
                title = "₹20 Medium Duo Showdown",
                category = TournamentCategory.DUO,
                entryFeePaise = 2000L, // ₹20
                maxSlots = 30,
                filledSlots = 20,
                matchFormat = MatchFormat.DUO,
                mapName = RoomType.KALAHARI,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 4, // 4 hours
                status = TournamentStatus.OPEN,
                roomId = "8829104",
                roomPassword = "DUO20",
                roomReleaseTime = "15 mins before match",
                description = "Competitive ₹20 duo showdown in the Kalahari desert. 85% prize pool payout + ₹5 per kill bonus.",
                rules = listOf(
                    "2 players per squad.",
                    "Map: Kalahari. Standard tournament settings."
                ),
                difficulty = TournamentDifficulty.MEDIUM
            ),
            TournamentItem(
                id = "tour_medium_cs_20",
                title = "₹20 Medium Clash Squad Pro",
                category = TournamentCategory.CLASH_SQUAD,
                entryFeePaise = 2000L, // ₹20
                maxSlots = 16,
                filledSlots = 10,
                matchFormat = MatchFormat.CLASH_4V4,
                mapName = RoomType.CUSTOM_MAP,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 5, // 5 hours
                status = TournamentStatus.OPEN,
                roomId = "9918234",
                roomPassword = "MED20",
                roomReleaseTime = "15 mins before match",
                description = "Medium tier 4v4 squad tournament with instant prize distribution to winners.",
                rules = listOf(
                    "4v4 Custom clash match.",
                    "First to 7 rounds wins."
                ),
                difficulty = TournamentDifficulty.MEDIUM
            ),
            TournamentItem(
                id = "tour_hard_20",
                title = "₹20 Hard Bermuda Sniper Elite",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 2000L, // ₹20
                maxSlots = 48,
                filledSlots = 40,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.PURGATORY,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 6, // 6 hours
                status = TournamentStatus.OPEN,
                roomId = "1129384",
                roomPassword = "HARD20",
                roomReleaseTime = "15 mins before match",
                description = "High intensity battle with competitive players. Extra kill points for snipers and top rank finish.",
                rules = listOf(
                    "Hardcore settings enabled.",
                    "Rank 1 takes 50% of the prize pool."
                ),
                difficulty = TournamentDifficulty.HARD
            ),

            // --- Standard, Hard & Mega Tournaments ---
            TournamentItem(
                id = "tour_hard_50",
                title = "Hardcore Pro League #88",
                category = TournamentCategory.CS_RANKED,
                entryFeePaise = 5000L, // ₹50
                maxSlots = 32,
                filledSlots = 24,
                matchFormat = MatchFormat.SQUAD,
                mapName = RoomType.CLASSIC_BERMUDA,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 7,
                status = TournamentStatus.OPEN,
                roomId = "3319284",
                roomPassword = "PRO88",
                roomReleaseTime = "15 mins before match",
                description = "Official Hardcore Pro League for experienced competitive teams.",
                rules = listOf("Verified IDs only.", "Level 40+ requirement."),
                difficulty = TournamentDifficulty.HARD
            ),
            TournamentItem(
                id = "tour_mega_100",
                title = "Mega Grand Royale #500",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 10000L, // ₹100
                maxSlots = 60,
                filledSlots = 48,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.CLASSIC_BERMUDA,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 8,
                status = TournamentStatus.OPEN,
                roomId = "4419203",
                roomPassword = "MEGA1",
                roomReleaseTime = "15 mins before match",
                description = "Mega ₹6,000 gross pool tournament with guaranteed ₹5,100 prize pool to Top 8 rankers.",
                rules = listOf("Strict esports compliance.", "Live stream recording."),
                difficulty = TournamentDifficulty.MEGA,
                customBannerRes = R.drawable.banner_aditya_founder_1787621660204
            ),
            TournamentItem(
                id = "tour_br_500",
                title = "Mega Grand Championship #104",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 50000L, // ₹500
                maxSlots = 60,
                filledSlots = 48,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.CLASSIC_BERMUDA,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 10,
                status = TournamentStatus.OPEN,
                roomId = "7729104",
                roomPassword = "WAR77",
                roomReleaseTime = "15 mins before match",
                description = "High octane 60-player solo battle royale. 80% Prize Pool distributed directly to Top 8 rankers + ₹10 kill rewards!",
                rules = listOf(
                    "Emulators, scripts, or third-party mods result in instant permanent ban.",
                    "Teaming up in Solo matches is strictly forbidden.",
                    "Room ID & password are strictly confidential for confirmed players.",
                    "Minimum level 25 Free Fire ID required for prize claiming."
                ),
                difficulty = TournamentDifficulty.MEGA,
                customBannerRes = R.drawable.banner_battle_royale_1787620022121
            ),
            TournamentItem(
                id = "tour_free_01",
                title = "Aditya Rookie Cup (Free Entry)",
                category = TournamentCategory.BATTLE_ROYALE,
                entryFeePaise = 0L, // Free
                maxSlots = 50,
                filledSlots = 35,
                matchFormat = MatchFormat.SOLO,
                mapName = RoomType.PURGATORY,
                scheduledTimeEpoch = System.currentTimeMillis() + 3600000L * 12,
                status = TournamentStatus.OPEN,
                description = "Free entry practice tournament for rising champions with coin and badge rewards.",
                rules = listOf("Open for all players.", "Winner gets 500 Aditya Coins and verified badge."),
                difficulty = TournamentDifficulty.EASY
            ),
            TournamentItem(
                id = "tour_live_01",
                title = "Midnight Thunder Royale",
                category = TournamentCategory.DUO,
                entryFeePaise = 20000L, // ₹200
                maxSlots = 40,
                filledSlots = 40,
                matchFormat = MatchFormat.DUO,
                mapName = RoomType.KALAHARI,
                scheduledTimeEpoch = System.currentTimeMillis() - 600000L, // Started 10m ago
                status = TournamentStatus.LIVE,
                roomId = "6619283",
                roomPassword = "MID9",
                description = "Live tournament currently underway in Kalahari desert.",
                rules = listOf("Match in progress."),
                difficulty = TournamentDifficulty.HARD
            ),
            TournamentItem(
                id = "tour_done_01",
                title = "Sunday Super Clash #101",
                category = TournamentCategory.CLASH_SQUAD,
                entryFeePaise = 10000L, // ₹100
                maxSlots = 16,
                filledSlots = 16,
                matchFormat = MatchFormat.CLASH_4V4,
                mapName = RoomType.CUSTOM_MAP,
                scheduledTimeEpoch = System.currentTimeMillis() - 86400000L, // Yesterday
                status = TournamentStatus.COMPLETED,
                roomId = "5519280",
                roomPassword = "SUN1",
                description = "Completed Sunday tournament.",
                rules = listOf("Final results recorded."),
                difficulty = TournamentDifficulty.NORMAL
            )
        )

        _tournaments.value = initialTournaments

        val initialGameModes = listOf(
            // BATTLE ROYALE
            ConfigurableGameMode("mode_br_solo", "BR Solo", TournamentCategory.BATTLE_ROYALE, isRanked = false, defaultMatchFormat = MatchFormat.SOLO, description = "Classic 48-player Free-For-All survival"),
            ConfigurableGameMode("mode_br_duo", "BR Duo", TournamentCategory.BATTLE_ROYALE, isRanked = false, defaultMatchFormat = MatchFormat.DUO, description = "2-Player squad tactical battle"),
            ConfigurableGameMode("mode_br_squad", "BR Squad", TournamentCategory.BATTLE_ROYALE, isRanked = false, defaultMatchFormat = MatchFormat.SQUAD, description = "Full 4-player team coordination royale"),
            ConfigurableGameMode("mode_br_rk_solo", "BR Ranked Solo", TournamentCategory.BATTLE_ROYALE, isRanked = true, defaultMatchFormat = MatchFormat.SOLO, description = "Competitive ranked solo showdown"),
            ConfigurableGameMode("mode_br_rk_duo", "BR Ranked Duo", TournamentCategory.BATTLE_ROYALE, isRanked = true, defaultMatchFormat = MatchFormat.DUO, description = "Ranked duo tournament ladder"),
            ConfigurableGameMode("mode_br_rk_squad", "BR Ranked Squad", TournamentCategory.BATTLE_ROYALE, isRanked = true, defaultMatchFormat = MatchFormat.SQUAD, description = "Premier ranked squad championship"),

            // CLASH SQUAD
            ConfigurableGameMode("mode_cs_1v1", "Clash Squad 1v1", TournamentCategory.CLASH_SQUAD, isRanked = false, defaultMatchFormat = MatchFormat.CLASH_1V1, description = "Intense 1v1 mechanical aim battle"),
            ConfigurableGameMode("mode_cs_2v2", "Clash Squad 2v2", TournamentCategory.CLASH_SQUAD, isRanked = false, defaultMatchFormat = MatchFormat.CLASH_2V2, description = "2v2 high-speed round clash"),
            ConfigurableGameMode("mode_cs_4v4", "Clash Squad 4v4", TournamentCategory.CLASH_SQUAD, isRanked = false, defaultMatchFormat = MatchFormat.CLASH_4V4, description = "Official 7-round esports 4v4 clash"),
            ConfigurableGameMode("mode_cs_ranked", "Clash Squad Ranked", TournamentCategory.CS_RANKED, isRanked = true, defaultMatchFormat = MatchFormat.CLASH_4V4, description = "Ranked 4v4 clash league"),

            // LONE WOLF
            ConfigurableGameMode("mode_lw_1v1", "Lone Wolf 1v1", TournamentCategory.LONE_WOLF, isRanked = false, defaultMatchFormat = MatchFormat.LONE_WOLF_1V1, description = "Pure skill 1v1 duel with weapon selection"),
            ConfigurableGameMode("mode_lw_2v2", "Lone Wolf 2v2", TournamentCategory.LONE_WOLF, isRanked = false, defaultMatchFormat = MatchFormat.LONE_WOLF_2V2, description = "2v2 dynamic duo wolf battle"),

            // OTHER COMPETITIVE MODES
            ConfigurableGameMode("mode_guild", "Guild Tournament", TournamentCategory.GUILD, defaultMatchFormat = MatchFormat.SQUAD, description = "Guild vs Guild clan championship"),
            ConfigurableGameMode("mode_custom", "Custom Tournament", TournamentCategory.CUSTOM, defaultMatchFormat = MatchFormat.SQUAD, description = "Custom rules, formats and arenas"),
            ConfigurableGameMode("mode_craftland", "Craftland / Custom Map", TournamentCategory.CRAFTLAND, defaultMatchFormat = MatchFormat.CLASH_4V4, description = "Custom created maps & special physics"),
            ConfigurableGameMode("mode_training", "Training / Practice", TournamentCategory.BATTLE_ROYALE, defaultMatchFormat = MatchFormat.SOLO, description = "Warm up and practice tournaments"),
            ConfigurableGameMode("mode_kill_challenge", "Kill Challenge", TournamentCategory.CHALLENGE, defaultMatchFormat = MatchFormat.SOLO, description = "Heavy kill bounty bonus points"),
            ConfigurableGameMode("mode_hs_challenge", "Headshot Challenge", TournamentCategory.CHALLENGE, defaultMatchFormat = MatchFormat.SOLO, description = "Headshot accuracy tournament"),
            ConfigurableGameMode("mode_survival_challenge", "Survival Challenge", TournamentCategory.CHALLENGE, defaultMatchFormat = MatchFormat.SOLO, description = "Survive to the final safe zones for multiplier points"),
            ConfigurableGameMode("mode_event", "Custom Event Mode", TournamentCategory.CUSTOM, defaultMatchFormat = MatchFormat.SQUAD, description = "Special weekend & holiday mega events")
        )
        _gameModes.value = initialGameModes

        val initialGameMaps = listOf(
            ConfigurableGameMap(
                id = "map_bermuda",
                name = "Bermuda Classic",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.CLASSIC_BERMUDA,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                minPlayers = 2,
                maxPlayers = 48,
                description = "Iconic island battlefield with Clock Tower, Factory, and Peak",
                customImageRes = R.drawable.banner_battle_royale_1787620022121
            ),
            ConfigurableGameMap(
                id = "map_purgatory",
                name = "Purgatory",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.PURGATORY,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                minPlayers = 2,
                maxPlayers = 48,
                description = "Expansive terrains, rivers, and hilltop snipers' vantage points"
            ),
            ConfigurableGameMap(
                id = "map_kalahari",
                name = "Kalahari Desert",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.KALAHARI,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                minPlayers = 2,
                maxPlayers = 48,
                description = "High elevation canyons, Refinery, and Submarine battle grounds"
            ),
            ConfigurableGameMap(
                id = "map_alpine",
                name = "Alpine Snow",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.ALPINE,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                minPlayers = 2,
                maxPlayers = 48,
                description = "Snowy mountainous village with rope bridges and train station"
            ),
            ConfigurableGameMap(
                id = "map_nexterra",
                name = "NexTerra",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.NEXTERRA,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                minPlayers = 2,
                maxPlayers = 48,
                description = "Futuristic tech arena with anti-gravity zones and portals"
            ),
            ConfigurableGameMap(
                id = "map_iron_cage",
                name = "Iron Cage",
                modeCategory = TournamentCategory.LONE_WOLF,
                roomType = RoomType.IRON_CAGE,
                supportedFormats = listOf(MatchFormat.LONE_WOLF_1V1, MatchFormat.LONE_WOLF_2V2, MatchFormat.CLASH_1V1),
                minPlayers = 2,
                maxPlayers = 16,
                description = "Enclosed gladiator arena designed for pure 1v1 and 2v2 duels"
            ),
            ConfigurableGameMap(
                id = "map_factory_roof",
                name = "Factory Roof Arena",
                modeCategory = TournamentCategory.CHALLENGE,
                roomType = RoomType.FACTORY_ROOF,
                supportedFormats = listOf(MatchFormat.SOLO, MatchFormat.CLASH_1V1),
                minPlayers = 2,
                maxPlayers = 30,
                description = "Fist fight and quick reflex close combat battleground"
            ),
            ConfigurableGameMap(
                id = "map_craftland_custom",
                name = "Craftland Arena",
                modeCategory = TournamentCategory.CRAFTLAND,
                roomType = RoomType.CUSTOM_MAP,
                supportedFormats = listOf(MatchFormat.CLASH_4V4, MatchFormat.SOLO, MatchFormat.DUO),
                minPlayers = 2,
                maxPlayers = 32,
                description = "Custom engineered competitive map with balanced obstacles"
            ),
            ConfigurableGameMap(
                id = "map_training",
                name = "Training Grounds",
                modeCategory = TournamentCategory.BATTLE_ROYALE,
                roomType = RoomType.TRAINING_ISLAND,
                supportedFormats = listOf(MatchFormat.SOLO),
                minPlayers = 2,
                maxPlayers = 20,
                description = "Practice target ranges and skirmish zone"
            )
        )
        _gameMaps.value = initialGameMaps

        val initialTransactions = listOf(
            WalletTransactionRecord(
                id = "tx_01",
                userId = "user_aditya_01",
                type = TransactionType.DEPOSIT,
                amountPaise = 50000L,
                balanceAfterPaise = 50000L,
                description = "Added money via Google Pay UPI",
                referenceId = "UPI-REF-9920194",
                timestamp = System.currentTimeMillis() - 86400000L * 3
            ),
            WalletTransactionRecord(
                id = "tx_02",
                userId = "user_aditya_01",
                type = TransactionType.TOURNAMENT_ENTRY,
                amountPaise = 10000L,
                balanceAfterPaise = 40000L,
                description = "Entry fee for Sunday Super Clash #101",
                referenceId = "JOIN-TOUR-101",
                timestamp = System.currentTimeMillis() - 86400000L * 1,
                tournamentTitle = "Sunday Super Clash #101"
            ),
            WalletTransactionRecord(
                id = "tx_03",
                userId = "user_aditya_01",
                type = TransactionType.TOURNAMENT_REWARD,
                amountPaise = 150000L,
                balanceAfterPaise = 190000L,
                description = "1st Place Prize - Sunday Super Clash #101",
                referenceId = "PRIZE-TOUR-101",
                timestamp = System.currentTimeMillis() - 86400000L * 1 + 3600000L,
                tournamentTitle = "Sunday Super Clash #101"
            )
        )
        _transactions.value = initialTransactions

        _dailyTasks.value = listOf(
            DailyTaskItem("task_01", "Daily Login", "Open Aditya Battle and check your dashboard", 50, 1, 1, false),
            DailyTaskItem("task_02", "Tournament Scout", "View details of at least 3 upcoming tournaments", 100, 2, 3, false),
            DailyTaskItem("task_03", "Battle Participation", "Join any free or paid tournament today", 250, 1, 1, false),
            DailyTaskItem("task_04", "Elimination Master", "Score 5+ kills in competitive tournaments", 500, 3, 5, false),
            DailyTaskItem("task_05", "Squad Inviter", "Share your referral code with a gaming friend", 300, 0, 1, false)
        )

        _notifications.value = listOf(
            NotificationItem(
                id = "notif_01",
                title = "Welcome to Aditya Battle!",
                message = "Your esports account is active. Verify KYC to unlock seamless bank withdrawals.",
                type = "SYSTEM",
                timestamp = System.currentTimeMillis() - 86400000L
            ),
            NotificationItem(
                id = "notif_02",
                title = "Prize Credited: ₹1,500",
                message = "Congratulations on securing Rank 1 in Sunday Super Clash #101!",
                type = "REWARD",
                timestamp = System.currentTimeMillis() - 43200000L
            )
        )

        // Seed initial completed match results
        _matchResults.value = mapOf(
            "tour_done_01" to listOf(
                MatchResultRecord(
                    id = "res_1",
                    tournamentId = "tour_done_01",
                    userId = "user_aditya_01",
                    username = "AdityaWarrior",
                    inGameName = "ShadowHunter",
                    kills = 9,
                    placement = 1,
                    killPoints = 90,
                    placementPoints = 100,
                    bonusPoints = 20,
                    totalPoints = 210,
                    rank = 1,
                    prizePaise = 150000L
                ),
                MatchResultRecord(
                    id = "res_2",
                    tournamentId = "tour_done_01",
                    userId = "user_02",
                    username = "ViperStrike",
                    inGameName = "ViperX",
                    kills = 6,
                    placement = 2,
                    killPoints = 60,
                    placementPoints = 75,
                    bonusPoints = 10,
                    totalPoints = 145,
                    rank = 2,
                    prizePaise = 60000L
                ),
                MatchResultRecord(
                    id = "res_3",
                    tournamentId = "tour_done_01",
                    userId = "user_03",
                    username = "PhoenixRider",
                    inGameName = "Phoenix99",
                    kills = 4,
                    placement = 3,
                    killPoints = 40,
                    placementPoints = 50,
                    bonusPoints = 0,
                    totalPoints = 90,
                    rank = 3,
                    prizePaise = 30000L
                )
            )
        )

        _allUsers.value = listOf(
            _currentUser.value!!,
            UserProfile("user_02", "ViperStrike", "viper@gmail.com", "+91 91234 56789", "ViperX", "99281726", role = UserRole.USER, kycStatus = KycStatus.VERIFIED, totalWins = 3, totalKills = 45),
            UserProfile("user_03", "PhoenixRider", "phoenix@gmail.com", "+91 93456 78901", "Phoenix99", "77182930", role = UserRole.USER, kycStatus = KycStatus.PENDING, totalWins = 2, totalKills = 38),
            UserProfile("user_admin", "AdityaAdmin", "admin@adityabattle.com", "+91 90000 00000", "AdityaBoss", "10000001", role = UserRole.ADMIN, kycStatus = KycStatus.VERIFIED, totalWins = 20, totalKills = 150)
        )

        _auditLogs.value = listOf(
            AuditLogEntry(
                id = "log_01",
                adminName = "System",
                action = "INITIALIZE_PLATFORM",
                target = "SYSTEM",
                details = "Aditya Battle Platform initialized with verified monetary engines."
            )
        )
    }

    // --- Authentication Operations ---

    fun login(emailOrMobile: String, password: String):Result<UserProfile> {
        val user = _allUsers.value.find {
            (it.email.equals(emailOrMobile, ignoreCase = true) || it.mobileNumber.contains(emailOrMobile))
        } ?: _currentUser.value!!
        _currentUser.value = user
        logAudit(user.username, "USER_LOGIN", user.id, "User logged in successfully.")
        return Result.success(user)
    }

    fun register(
        username: String,
        email: String,
        mobileNumber: String,
        password: String,
        referralCode: String?
    ): Result<UserProfile> {
        val newUser = UserProfile(
            id = "user_${UUID.randomUUID().toString().take(8)}",
            username = username,
            email = email,
            mobileNumber = mobileNumber,
            role = UserRole.USER,
            kycStatus = KycStatus.NOT_SUBMITTED,
            referralCode = "ADITYA${(10..99).random()}",
            referredBy = referralCode,
            totalTournaments = 0,
            totalWins = 0,
            totalKills = 0
        )
        _allUsers.value = _allUsers.value + newUser
        _currentUser.value = newUser

        if (!referralCode.isNullOrBlank()) {
            // Award bonus coins for referral
            _walletState.value = _walletState.value.copy(
                coinBalance = _walletState.value.coinBalance + 200L
            )
            addNotification(
                title = "Referral Bonus Received!",
                message = "200 Aditya Coins credited using referral code $referralCode",
                type = "REFERRAL"
            )
        }

        logAudit(username, "USER_REGISTER", newUser.id, "New account registered with email $email")
        return Result.success(newUser)
    }

    fun toggleRole() {
        val current = _currentUser.value ?: return
        val newRole = if (current.role == UserRole.USER) UserRole.ADMIN else UserRole.USER
        _currentUser.value = current.copy(role = newRole)
        logAudit(current.username, "ROLE_SWITCH", current.id, "Switched role to $newRole for testing.")
    }

    fun logout() {
        _currentUser.value = null
    }

    // --- Tournament Join System (Atomic with Mutex) ---

    suspend fun joinTournament(
        tournamentId: String,
        inGameName: String,
        inGameId: String
    ): Result<String> = joinMutex.withLock {
        val user = _currentUser.value ?: return Result.failure(Exception("User not authenticated"))
        val tournament = _tournaments.value.find { it.id == tournamentId }
            ?: return Result.failure(Exception("Tournament does not exist"))

        if (tournament.status != TournamentStatus.OPEN) {
            return Result.failure(Exception("Tournament is not open for registration"))
        }

        if (tournament.isFull) {
            return Result.failure(Exception("Tournament slots are completely filled"))
        }

        if (tournament.isJoined) {
            return Result.failure(Exception("You have already registered for this tournament"))
        }

        val feePaise = tournament.entryFeePaise
        val currentWallet = _walletState.value

        if (feePaise > 0) {
            if (currentWallet.totalBalancePaise < feePaise) {
                return Result.failure(
                    Exception("Insufficient wallet balance! Need ${MoneyEngine.formatRupees(feePaise)}, available: ${MoneyEngine.formatRupees(currentWallet.totalBalancePaise)}. Please add money to continue.")
                )
            }

            // Deduct entry fee atomically: deduct from deposit balance first, remainder from winning balance
            var depositDeduct = minOf(currentWallet.depositBalancePaise, feePaise)
            var winningDeduct = feePaise - depositDeduct

            val newDepositBalance = currentWallet.depositBalancePaise - depositDeduct
            val newWinningBalance = currentWallet.winningWithdrawablePaise - winningDeduct

            _walletState.value = currentWallet.copy(
                depositBalancePaise = newDepositBalance,
                winningWithdrawablePaise = newWinningBalance
            )

            // Create immutable wallet transaction record
            val txRecord = WalletTransactionRecord(
                id = "tx_${UUID.randomUUID().toString().take(8)}",
                userId = user.id,
                type = TransactionType.TOURNAMENT_ENTRY,
                amountPaise = feePaise,
                balanceAfterPaise = newDepositBalance + newWinningBalance,
                description = "Entry Fee for ${tournament.title}",
                referenceId = "JOIN-${tournament.id.takeLast(6).uppercase()}",
                timestamp = System.currentTimeMillis(),
                tournamentTitle = tournament.title
            )
            _transactions.value = listOf(txRecord) + _transactions.value
        }

        // Update tournament slot count and joined flag
        val updatedTournaments = _tournaments.value.map {
            if (it.id == tournamentId) {
                val newFilled = it.filledSlots + 1
                it.copy(
                    filledSlots = newFilled,
                    status = if (newFilled >= it.maxSlots) TournamentStatus.FULL else it.status,
                    isJoined = true
                )
            } else it
        }
        _tournaments.value = updatedTournaments

        // Update user in-game stats
        _currentUser.value = user.copy(
            inGameName = inGameName.ifBlank { user.inGameName },
            inGameId = inGameId.ifBlank { user.inGameId },
            totalTournaments = user.totalTournaments + 1
        )

        // Increment daily task progress
        incrementTaskProgress("task_03", 1)

        // Send confirmation notification
        addNotification(
            title = "Tournament Registered!",
            message = "You joined ${tournament.title}. Room credentials will unlock prior to match time.",
            type = "TOURNAMENT"
        )

        logAudit(
            user.username,
            "JOIN_TOURNAMENT",
            tournamentId,
            "Joined tournament ${tournament.title} with fee ${MoneyEngine.formatRupees(feePaise)}"
        )

        return Result.success("Successfully joined tournament! Slot reserved.")
    }

    // --- Deposit System ---

    fun addMoney(amountPaise: Long, method: PaymentMethod): Result<String> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        if (amountPaise <= 0) return Result.failure(Exception("Invalid amount"))

        val currentWallet = _walletState.value
        val newDeposit = currentWallet.depositBalancePaise + amountPaise
        _walletState.value = currentWallet.copy(depositBalancePaise = newDeposit)

        val tx = WalletTransactionRecord(
            id = "dep_${UUID.randomUUID().toString().take(8)}",
            userId = user.id,
            type = TransactionType.DEPOSIT,
            amountPaise = amountPaise,
            balanceAfterPaise = newDeposit + currentWallet.winningWithdrawablePaise,
            description = "Deposit via ${method.displayName}",
            referenceId = "PAY-${(100000..999999).random()}",
            status = TransactionStatus.COMPLETED
        )
        _transactions.value = listOf(tx) + _transactions.value

        addNotification(
            title = "Deposit Successful: ${MoneyEngine.formatRupees(amountPaise)}",
            message = "Amount successfully credited to your game wallet via ${method.displayName}.",
            type = "DEPOSIT"
        )

        logAudit(user.username, "ADD_MONEY", user.id, "Deposited ${MoneyEngine.formatRupees(amountPaise)} via ${method.name}")
        return Result.success("Deposit of ${MoneyEngine.formatRupees(amountPaise)} successful!")
    }

    // --- Withdrawal System ---

    fun withdrawMoney(amountPaise: Long, method: WithdrawalMethod, destination: String): Result<String> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        val currentWallet = _walletState.value

        if (user.kycStatus != KycStatus.VERIFIED) {
            return Result.failure(Exception("KYC verification required before withdrawing funds."))
        }

        if (amountPaise < 10000L) { // Min ₹100
            return Result.failure(Exception("Minimum withdrawal limit is ₹100 (10,000 paise)."))
        }

        if (amountPaise > currentWallet.winningWithdrawablePaise) {
            return Result.failure(
                Exception("Insufficient withdrawable balance. Available: ${MoneyEngine.formatRupees(currentWallet.winningWithdrawablePaise)}")
            )
        }

        val newWinning = currentWallet.winningWithdrawablePaise - amountPaise
        _walletState.value = currentWallet.copy(winningWithdrawablePaise = newWinning)

        val tx = WalletTransactionRecord(
            id = "wth_${UUID.randomUUID().toString().take(8)}",
            userId = user.id,
            type = TransactionType.WITHDRAWAL,
            amountPaise = amountPaise,
            balanceAfterPaise = currentWallet.depositBalancePaise + newWinning,
            description = "Withdrawal to $destination (${method.displayName})",
            referenceId = "WTH-${(100000..999999).random()}",
            status = TransactionStatus.COMPLETED
        )
        _transactions.value = listOf(tx) + _transactions.value

        addNotification(
            title = "Withdrawal Processed: ${MoneyEngine.formatRupees(amountPaise)}",
            message = "Funds sent to $destination. Bank reference IMPS-${(10000000..99999999).random()}",
            type = "WITHDRAWAL"
        )

        logAudit(user.username, "WITHDRAWAL", user.id, "Withdrew ${MoneyEngine.formatRupees(amountPaise)} to $destination")
        return Result.success("Withdrawal of ${MoneyEngine.formatRupees(amountPaise)} processed successfully!")
    }

    // --- KYC Submission ---

    fun submitKyc(submission: KycSubmission): Result<String> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        if (submission.fullName.isBlank() || submission.panNumber.isBlank()) {
            return Result.failure(Exception("Please fill all required KYC fields."))
        }

        val updatedUser = user.copy(kycStatus = KycStatus.VERIFIED)
        _currentUser.value = updatedUser
        _allUsers.value = _allUsers.value.map { if (it.id == user.id) updatedUser else it }

        addNotification(
            title = "KYC Verified Successfully",
            message = "Your identity and tax details have been verified. Unlimited withdrawals unlocked.",
            type = "KYC"
        )

        logAudit(user.username, "SUBMIT_KYC", user.id, "KYC verified for ${submission.fullName} (PAN: ${submission.panNumber})")
        return Result.success("KYC details submitted and verified!")
    }

    // --- Daily Tasks and Streak Claiming ---

    fun claimDailyReward(): Result<String> {
        _walletState.value = _walletState.value.copy(
            coinBalance = _walletState.value.coinBalance + 100L
        )
        addNotification("Daily Reward Claimed", "Received 100 Aditya Coins for daily streak!", "REWARD")
        return Result.success("Claimed 100 Aditya Coins!")
    }

    fun claimTaskReward(taskId: String): Result<String> {
        val task = _dailyTasks.value.find { it.id == taskId } ?: return Result.failure(Exception("Task not found"))
        if (task.isClaimed) return Result.failure(Exception("Task reward already claimed"))
        if (task.currentProgress < task.maxProgress) return Result.failure(Exception("Task requirements not yet completed"))

        _dailyTasks.value = _dailyTasks.value.map {
            if (it.id == taskId) it.copy(isClaimed = true) else it
        }

        _walletState.value = _walletState.value.copy(
            coinBalance = _walletState.value.coinBalance + task.rewardCoins
        )

        addNotification("Task Completed: ${task.title}", "Earned ${task.rewardCoins} coins!", "TASK")
        return Result.success("Earned ${task.rewardCoins} Aditya Coins!")
    }

    fun incrementTaskProgress(taskId: String, amount: Int) {
        _dailyTasks.value = _dailyTasks.value.map {
            if (it.id == taskId) {
                val newProg = (it.currentProgress + amount).coerceAtMost(it.maxProgress)
                it.copy(currentProgress = newProg)
            } else it
        }
    }

    // --- Admin Operations ---

    fun adminCreateTournament(
        title: String,
        category: TournamentCategory,
        entryFeePaise: Long,
        maxSlots: Int,
        matchFormat: MatchFormat,
        mapName: RoomType,
        scheduledHoursFromNow: Int,
        description: String,
        rules: List<String>,
        difficulty: TournamentDifficulty = TournamentDifficulty.NORMAL
    ): Result<TournamentItem> {
        val tier = when {
            entryFeePaise == 0L -> TournamentTierType.FREE
            entryFeePaise <= 10000L -> TournamentTierType.LOW_ENTRY
            entryFeePaise <= 100000L -> TournamentTierType.MEDIUM_ENTRY
            else -> TournamentTierType.HIGH_ENTRY
        }
        val formatType = when (matchFormat) {
            MatchFormat.CLASH_4V4, MatchFormat.CLASH_1V1, MatchFormat.CLASH_2V2 -> TournamentFormatType.BEST_OF_3
            MatchFormat.LONE_WOLF_1V1, MatchFormat.LONE_WOLF_2V2 -> TournamentFormatType.BEST_OF_5
            else -> TournamentFormatType.SINGLE_MATCH
        }
        return adminCreateTournamentUniversal(
            TournamentItem(
                id = "tour_${UUID.randomUUID().toString().take(8)}",
                title = title,
                category = category,
                entryFeePaise = entryFeePaise,
                maxSlots = maxSlots,
                filledSlots = 0,
                matchFormat = matchFormat,
                mapName = mapName,
                scheduledTimeEpoch = System.currentTimeMillis() + scheduledHoursFromNow * 3600000L,
                status = TournamentStatus.OPEN,
                description = description,
                rules = rules,
                difficulty = difficulty,
                formatType = formatType,
                tierType = tier
            )
        )
    }

    fun adminCreateTournamentUniversal(tournament: TournamentItem): Result<TournamentItem> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        // Financial validation
        if (tournament.entryFeePaise < 0L) {
            return Result.failure(Exception("Entry fee cannot be negative."))
        }
        if (tournament.entryFeePaise > 0L && !MoneyEngine.isValidPaidEntryFee(tournament.entryFeePaise)) {
            return Result.failure(Exception("Entry fee must be between ₹5 and ₹10,000."))
        }
        if (tournament.maxSlots <= 1) {
            return Result.failure(Exception("Slots must be greater than 1."))
        }

        // Automatic financial calculation verification
        val calc = MoneyEngine.calculateDistribution(tournament.entryFeePaise, tournament.maxSlots)
        if (tournament.entryFeePaise > 0L) {
            val verifiedGross = calc.prizePoolPaise + calc.platformSharePaise
            if (verifiedGross != calc.grossPoolPaise) {
                return Result.failure(Exception("Financial arithmetic verification failed."))
            }
        }

        _tournaments.value = listOf(tournament) + _tournaments.value
        logAudit(
            admin.username,
            "CREATE_UNIVERSAL_TOURNAMENT",
            tournament.id,
            "Created ${tournament.title} | Mode: ${tournament.category.displayName} | Fee: ${MoneyEngine.formatRupees(tournament.entryFeePaise)} | Slots: ${tournament.maxSlots}"
        )
        return Result.success(tournament)
    }

    fun adminGenerateTournament(
        mode: ConfigurableGameMode,
        map: ConfigurableGameMap,
        matchFormat: MatchFormat,
        entryFeeRupees: Long,
        slots: Int,
        hoursFromNow: Int,
        formatType: TournamentFormatType = TournamentFormatType.SINGLE_MATCH,
        difficulty: TournamentDifficulty = TournamentDifficulty.NORMAL
    ): Result<TournamentItem> {
        val entryFeePaise = MoneyEngine.rupeesToPaise(entryFeeRupees)
        val feeLabel = if (entryFeeRupees == 0L) "FREE" else "₹$entryFeeRupees"
        val title = "$feeLabel ${mode.name} • ${map.name}"
        val desc = "Universal tournament for ${mode.name} on ${map.name}. ${formatType.description}. Prize Pool: 85% for ₹1-₹100, 80% for ₹101-₹10,000."
        val rules = listOf(
            "Game Mode: ${mode.name} (${matchFormat.label})",
            "Map: ${map.name} (${map.description})",
            "Format: ${formatType.label}",
            "Fair play guaranteed. Anti-cheat monitoring active."
        )
        val tier = when {
            entryFeeRupees == 0L -> TournamentTierType.FREE
            entryFeeRupees <= 100L -> TournamentTierType.LOW_ENTRY
            entryFeeRupees <= 1000L -> TournamentTierType.MEDIUM_ENTRY
            else -> TournamentTierType.HIGH_ENTRY
        }
        val item = TournamentItem(
            id = "tour_${UUID.randomUUID().toString().take(8)}",
            title = title,
            category = mode.parentCategory,
            entryFeePaise = entryFeePaise,
            maxSlots = slots,
            filledSlots = 0,
            matchFormat = matchFormat,
            mapName = map.roomType,
            scheduledTimeEpoch = System.currentTimeMillis() + hoursFromNow * 3600000L,
            status = TournamentStatus.OPEN,
            description = desc,
            rules = rules,
            difficulty = difficulty,
            formatType = formatType,
            tierType = tier,
            gameModeName = mode.name,
            customBannerRes = map.customImageRes
        )
        return adminCreateTournamentUniversal(item)
    }

    // --- Admin Map Management ---

    fun adminAddMap(
        name: String,
        modeCategory: TournamentCategory,
        roomType: RoomType,
        supportedFormats: List<MatchFormat>,
        minPlayers: Int,
        maxPlayers: Int,
        description: String = "",
        isEnabled: Boolean = true
    ): Result<ConfigurableGameMap> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))
        if (name.isBlank()) return Result.failure(Exception("Map name cannot be blank"))

        val newMap = ConfigurableGameMap(
            id = "map_${UUID.randomUUID().toString().take(8)}",
            name = name.trim(),
            modeCategory = modeCategory,
            roomType = roomType,
            isEnabled = isEnabled,
            supportedFormats = supportedFormats.ifEmpty { listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD) },
            minPlayers = minPlayers.coerceAtLeast(1),
            maxPlayers = maxPlayers.coerceAtLeast(minPlayers),
            description = description.trim()
        )
        _gameMaps.value = _gameMaps.value + newMap
        logAudit(admin.username, "ADD_MAP", newMap.id, "Added new map: ${newMap.name}")
        return Result.success(newMap)
    }

    fun adminUpdateMap(map: ConfigurableGameMap): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        _gameMaps.value = _gameMaps.value.map { if (it.id == map.id) map else it }
        logAudit(admin.username, "UPDATE_MAP", map.id, "Updated map: ${map.name}")
        return Result.success("Map '${map.name}' updated successfully")
    }

    fun adminToggleMap(mapId: String, isEnabled: Boolean): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        _gameMaps.value = _gameMaps.value.map { if (it.id == mapId) it.copy(isEnabled = isEnabled) else it }
        logAudit(admin.username, "TOGGLE_MAP", mapId, "Set map enabled=$isEnabled")
        return Result.success("Map status updated")
    }

    fun adminDeleteMap(mapId: String): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        val map = _gameMaps.value.find { it.id == mapId } ?: return Result.failure(Exception("Map not found"))
        _gameMaps.value = _gameMaps.value.filterNot { it.id == mapId }
        logAudit(admin.username, "DELETE_MAP", mapId, "Deleted map: ${map.name}")
        return Result.success("Map '${map.name}' deleted")
    }

    // --- Admin Game Mode Management ---

    fun adminToggleGameMode(modeId: String, isEnabled: Boolean): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        _gameModes.value = _gameModes.value.map { if (it.id == modeId) it.copy(isEnabled = isEnabled) else it }
        logAudit(admin.username, "TOGGLE_MODE", modeId, "Set mode enabled=$isEnabled")
        return Result.success("Game mode status updated")
    }

    fun adminUpdateRoom(tournamentId: String, roomId: String, password: String): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        _tournaments.value = _tournaments.value.map {
            if (it.id == tournamentId) {
                it.copy(roomId = roomId, roomPassword = password, status = TournamentStatus.LIVE)
            } else it
        }

        addNotification(
            title = "Room Credentials Released!",
            message = "Room ID & Password for your upcoming match have been published.",
            type = "ROOM"
        )

        logAudit(admin.username, "UPDATE_ROOM", tournamentId, "Updated Room ID: $roomId")
        return Result.success("Room credentials updated and notified to players!")
    }

    fun adminFinalizeResults(
        tournamentId: String,
        results: List<MatchResultRecord>
    ): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        if (admin.role != UserRole.ADMIN) return Result.failure(Exception("Admin privileges required"))

        val tournament = _tournaments.value.find { it.id == tournamentId }
            ?: return Result.failure(Exception("Tournament not found"))

        // Update match results map
        val updatedMap = _matchResults.value.toMutableMap()
        updatedMap[tournamentId] = results
        _matchResults.value = updatedMap

        // Mark tournament completed
        _tournaments.value = _tournaments.value.map {
            if (it.id == tournamentId) it.copy(status = TournamentStatus.COMPLETED) else it
        }

        // Payout winnings to current user if they won
        val userResult = results.find { it.userId == admin.id || it.userId == "user_aditya_01" }
        if (userResult != null && userResult.prizePaise > 0) {
            val curWallet = _walletState.value
            val newWinning = curWallet.winningWithdrawablePaise + userResult.prizePaise
            _walletState.value = curWallet.copy(winningWithdrawablePaise = newWinning)

            val tx = WalletTransactionRecord(
                id = "pz_${UUID.randomUUID().toString().take(8)}",
                userId = userResult.userId,
                type = TransactionType.TOURNAMENT_REWARD,
                amountPaise = userResult.prizePaise,
                balanceAfterPaise = curWallet.depositBalancePaise + newWinning,
                description = "Rank ${userResult.rank} Prize for ${tournament.title}",
                referenceId = "WIN-${tournament.id.takeLast(6).uppercase()}",
                tournamentTitle = tournament.title
            )
            _transactions.value = listOf(tx) + _transactions.value

            addNotification(
                title = "Winner! Rank ${userResult.rank}",
                message = "You won ${MoneyEngine.formatRupees(userResult.prizePaise)} in ${tournament.title}!",
                type = "PRIZE"
            )
        }

        logAudit(admin.username, "FINALIZE_MATCH", tournamentId, "Finalized results and distributed rank prizes for ${tournament.title}")
        return Result.success("Match results finalized and prize money credited!")
    }

    fun adminCancelTournament(tournamentId: String, reason: String): Result<String> {
        val admin = _currentUser.value ?: return Result.failure(Exception("Not authorized"))
        val tour = _tournaments.value.find { it.id == tournamentId } ?: return Result.failure(Exception("Tournament not found"))

        _tournaments.value = _tournaments.value.map {
            if (it.id == tournamentId) it.copy(status = TournamentStatus.CANCELLED) else it
        }

        // Refund if joined
        if (tour.isJoined && tour.entryFeePaise > 0) {
            val cur = _walletState.value
            val newDeposit = cur.depositBalancePaise + tour.entryFeePaise
            _walletState.value = cur.copy(depositBalancePaise = newDeposit)

            val refundTx = WalletTransactionRecord(
                id = "ref_${UUID.randomUUID().toString().take(8)}",
                userId = admin.id,
                type = TransactionType.REFUND,
                amountPaise = tour.entryFeePaise,
                balanceAfterPaise = newDeposit + cur.winningWithdrawablePaise,
                description = "Refund: ${tour.title} ($reason)",
                referenceId = "REF-${tour.id.takeLast(6).uppercase()}",
                tournamentTitle = tour.title
            )
            _transactions.value = listOf(refundTx) + _transactions.value

            addNotification(
                title = "Tournament Cancelled & Refunded",
                message = "${tour.title} was cancelled: $reason. ${MoneyEngine.formatRupees(tour.entryFeePaise)} refunded.",
                type = "REFUND"
            )
        }

        logAudit(admin.username, "CANCEL_TOURNAMENT", tournamentId, "Cancelled tournament: $reason")
        return Result.success("Tournament cancelled and refunds processed.")
    }

    private fun addNotification(title: String, message: String, type: String) {
        val item = NotificationItem(
            id = "notif_${UUID.randomUUID().toString().take(8)}",
            title = title,
            message = message,
            type = type,
            timestamp = System.currentTimeMillis()
        )
        _notifications.value = listOf(item) + _notifications.value
    }

    private fun logAudit(adminName: String, action: String, target: String, details: String) {
        val entry = AuditLogEntry(
            id = "audit_${UUID.randomUUID().toString().take(8)}",
            adminName = adminName,
            action = action,
            target = target,
            details = details,
            timestamp = System.currentTimeMillis()
        )
        _auditLogs.value = listOf(entry) + _auditLogs.value
    }
}
