package com.example.ui.screens.auth

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    onLoginSuccess: (emailOrPhone: String, pass: String) -> Unit,
    onRegisterSuccess: (name: String, email: String, phone: String, pass: String, refCode: String?) -> Unit,
    onSkipForDemo: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var emailOrPhone by remember { mutableStateOf("aditya.esports@battle.in") }
    var mobileNumber by remember { mutableStateOf("+91 98765 43210") }
    var password by remember { mutableStateOf("AdityaPass123") }
    var confirmPassword by remember { mutableStateOf("AdityaPass123") }
    var referralCode by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var termsAccepted by remember { mutableStateOf(true) }
    var showOtpDialog by remember { mutableStateOf(false) }
    var enteredOtp by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // App Emblem
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(EsportsCyan, EsportsCrimson)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = "Logo",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "ADITYA BATTLE",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp,
                color = EsportsCyan
            )

            Text(
                text = "Online Esports Tournament Platform",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Mode Selector Tabs (Login / Register)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(4.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (!isRegisterMode) EsportsCyan else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { isRegisterMode = false }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(
                            text = "LOGIN",
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (!isRegisterMode) Color.Black else TextSecondary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isRegisterMode) EsportsCyan else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { isRegisterMode = true }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(
                            text = "REGISTER",
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (isRegisterMode) Color.Black else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isRegisterMode) {
                // Register Fields
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Gamer Username") },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = EsportsCyan) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = emailOrPhone,
                    onValueChange = { emailOrPhone = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, tint = EsportsCyan) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { mobileNumber = it },
                    label = { Text("Mobile Number (for OTP & Withdrawals)") },
                    leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null, tint = EsportsCyan) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = referralCode,
                    onValueChange = { referralCode = it },
                    label = { Text("Referral Code (Optional - Get 200 Coins)") },
                    leadingIcon = { Icon(Icons.Filled.CardGiftcard, contentDescription = null, tint = EsportsGold) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
            } else {
                // Login Fields
                OutlinedTextField(
                    value = emailOrPhone,
                    onValueChange = { emailOrPhone = it },
                    label = { Text("Email or Mobile Number") },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = EsportsCyan) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Password Field
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = EsportsCyan) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password",
                            tint = TextSecondary
                        )
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EsportsCyan,
                    unfocusedBorderColor = CardBorder,
                    focusedContainerColor = EsportsSurface,
                    unfocusedContainerColor = EsportsSurface
                ),
                modifier = Modifier.fillMaxWidth()
            )

            if (isRegisterMode) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("Confirm Password") },
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = EsportsCyan) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsSurface,
                        unfocusedContainerColor = EsportsSurface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Terms & Compliance Checkbox
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = termsAccepted,
                    onCheckedChange = { termsAccepted = it },
                    colors = CheckboxDefaults.colors(checkedColor = EsportsCyan)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "I confirm I am 18+ years of age and agree to the Terms of Service & Fair Play Rules.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Action Button
            Button(
                onClick = {
                    if (isRegisterMode) {
                        showOtpDialog = true
                    } else {
                        onLoginSuccess(emailOrPhone, password)
                    }
                },
                enabled = termsAccepted && emailOrPhone.isNotBlank() && password.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("auth_primary_button")
            ) {
                Text(
                    text = if (isRegisterMode) "SEND OTP & VERIFY" else "ENTER TOURNAMENT ARENA",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Demo Quick Login
            OutlinedButton(
                onClick = onSkipForDemo,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CardBorderNeon),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.FlashOn,
                    contentDescription = null,
                    tint = EsportsGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "QUICK DEMO ACCESS (PRO PLAYER)",
                    color = EsportsGold,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // OTP Verification Dialog
    if (showOtpDialog) {
        AlertDialog(
            onDismissRequest = { showOtpDialog = false },
            title = {
                Text(text = "Enter 6-Digit OTP", color = EsportsCyan, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "We sent an OTP code to $mobileNumber for two-factor authentication.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = enteredOtp,
                        onValueChange = { if (it.length <= 6) enteredOtp = it },
                        label = { Text("Demo OTP: 123456") },
                        placeholder = { Text("123456") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOtpDialog = false
                        onRegisterSuccess(
                            username.ifBlank { "Player_${(100..999).random()}" },
                            emailOrPhone,
                            mobileNumber,
                            password,
                            referralCode.ifBlank { null }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan)
                ) {
                    Text("VERIFY & COMPLETE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOtpDialog = false }) {
                    Text("CANCEL", color = TextSecondary)
                }
            },
            containerColor = EsportsSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
