package com.example.ui.dialogs

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinTournamentBottomSheet(
    tournament: TournamentItem,
    walletState: WalletState,
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onConfirmJoin: (inGameName: String, inGameId: String) -> Unit,
    onAddMoneyRequired: () -> Unit
) {
    var inGameName by remember { mutableStateOf(currentUser?.inGameName ?: "ShadowHunter") }
    var inGameId by remember { mutableStateOf(currentUser?.inGameId ?: "84920481") }
    val entryFeePaise = tournament.entryFeePaise
    val hasSufficientBalance = tournament.isFree || walletState.totalBalancePaise >= entryFeePaise
    val modalBottomSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = modalBottomSheetState,
        containerColor = EsportsSurface,
        scrimColor = Color.Black.copy(alpha = 0.7f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CONFIRM REGISTRATION",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = EsportsCyan
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = tournament.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Entry Fee & Balance Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (hasSufficientBalance) CardBorderNeon else CardBorderCrimson
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Entry Fee Required:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text(
                            text = if (tournament.isFree) "FREE (0.00)" else "${MoneyEngine.formatRupees(entryFeePaise)} / player",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = if (tournament.isFree) EsportsGreen else EsportsCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Your Available Balance:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text(
                            text = MoneyEngine.formatRupees(walletState.totalBalancePaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (hasSufficientBalance) EsportsGreen else EsportsCrimson
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // In Game Credentials
            Text(
                text = "Verify Game Profile Credentials",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = inGameName,
                onValueChange = { inGameName = it },
                label = { Text("Free Fire In-Game Name (IGN)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = inGameId,
                onValueChange = { inGameId = it },
                label = { Text("Game UID (In-Game ID)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (hasSufficientBalance) {
                Button(
                    onClick = { onConfirmJoin(inGameName, inGameId) },
                    enabled = inGameName.isNotBlank() && inGameId.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tournament.isFree) EsportsGreen else EsportsCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_join_modal_button")
                ) {
                    Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (tournament.isFree) "REGISTER FREE NOW" else "PAY ${MoneyEngine.formatRupees(entryFeePaise)} & JOIN",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            } else {
                Button(
                    onClick = onAddMoneyRequired,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsCrimson),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INSUFFICIENT BALANCE • ADD MONEY",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun KycVerificationDialog(
    onDismiss: () -> Unit,
    onSubmitKyc: (KycSubmission) -> Unit
) {
    var fullName by remember { mutableStateOf("Aditya Sharma") }
    var dob by remember { mutableStateOf("15/08/1998") }
    var panNumber by remember { mutableStateOf("ABCDE1234F") }
    var aadharLast4 by remember { mutableStateOf("8821") }
    var upiId by remember { mutableStateOf("aditya.battle@okhdfcbank") }
    var bankAccount by remember { mutableStateOf("5010029381928") }
    var ifscCode by remember { mutableStateOf("HDFC0001234") }
    var state by remember { mutableStateOf("Maharashtra") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("KYC & Tax Verification", color = EsportsCyan, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "As per Indian regulatory norms for esports skill gaming platforms, verify identity to enable seamless bank withdrawals.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Legal Name (as per PAN)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = panNumber,
                    onValueChange = { panNumber = it.uppercase() },
                    label = { Text("PAN Card Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("UPI ID (For Instant Payouts)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bankAccount,
                    onValueChange = { bankAccount = it },
                    label = { Text("Bank Account Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = ifscCode,
                    onValueChange = { ifscCode = it.uppercase() },
                    label = { Text("Bank IFSC Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmitKyc(
                        KycSubmission(
                            fullName = fullName,
                            dateOfBirth = dob,
                            panNumber = panNumber,
                            aadharLast4 = aadharLast4,
                            upiId = upiId,
                            bankAccountNumber = bankAccount,
                            ifscCode = ifscCode,
                            state = state
                        )
                    )
                },
                enabled = fullName.isNotBlank() && panNumber.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan)
            ) {
                Text("VERIFY KYC & UNLOCK WITHDRAWAL", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextSecondary)
            }
        },
        containerColor = EsportsSurface,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun ComplianceDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Fair Play & Legal Compliance", color = EsportsGold, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "1. Game of Skill Legal Recognition\n" +
                            "Tournaments hosted on Aditya Battle are games of skill under Indian Law. Outcomes depend predominantly on player mechanical skill, aiming reflex, map awareness, and squad coordination.\n\n" +
                            "2. Age Restriction (18+)\n" +
                            "Only users aged 18 years and above are permitted to participate in paid tournaments or real-money withdrawals.\n\n" +
                            "3. State Restrictions\n" +
                            "Residents of states where paid gaming is restricted (Assam, Odisha, Nagaland, Sikkim, Telangana, Andhra Pradesh) are restricted to free practice cups only.\n\n" +
                            "4. Anti-Cheat & Fair Play\n" +
                            "Use of emulators, modded APKs, script aimbots, or cross-teaming will result in permanent hardware ban and forfeiture of wallet balance.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EsportsGold)
            ) {
                Text("I UNDERSTAND & AGREE", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = EsportsSurface,
        shape = RoundedCornerShape(16.dp)
    )
}
