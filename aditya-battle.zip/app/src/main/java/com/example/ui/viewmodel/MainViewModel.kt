package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.data.repository.EsportsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface UiMessage {
    data class Success(val message: String) : UiMessage
    data class Error(val message: String) : UiMessage
}

class MainViewModel(private val repository: EsportsRepository) : ViewModel() {

    val currentUser: StateFlow<UserProfile?> = repository.currentUser
    val walletState: StateFlow<WalletState> = repository.walletState
    val tournaments: StateFlow<List<TournamentItem>> = repository.tournaments
    val transactions: StateFlow<List<WalletTransactionRecord>> = repository.transactions
    val dailyTasks: StateFlow<List<DailyTaskItem>> = repository.dailyTasks
    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
    val matchResults: StateFlow<Map<String, List<MatchResultRecord>>> = repository.matchResults
    val allUsers: StateFlow<List<UserProfile>> = repository.allUsers
    val auditLogs: StateFlow<List<AuditLogEntry>> = repository.auditLogs
    val gameModes: StateFlow<List<ConfigurableGameMode>> = repository.gameModes
    val gameMaps: StateFlow<List<ConfigurableGameMap>> = repository.gameMaps
    val banners = repository.banners

    // UI Message Events
    private val _uiMessage = MutableSharedFlow<UiMessage>()
    val uiMessage = _uiMessage.asSharedFlow()

    // Filter states
    private val _selectedCategory = MutableStateFlow<TournamentCategory?>(null)
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<TournamentStatus?>(null)
    val selectedStatusFilter = _selectedStatusFilter.asStateFlow()

    val filteredTournaments: StateFlow<List<TournamentItem>> = combine(
        tournaments,
        selectedCategory,
        searchQuery,
        selectedStatusFilter
    ) { tourList, category, query, status ->
        tourList.filter { tour ->
            (category == null || tour.category == category) &&
            (status == null || tour.status == status) &&
            (query.isBlank() || tour.title.contains(query, ignoreCase = true) || tour.category.displayName.contains(query, ignoreCase = true))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myTournaments: StateFlow<List<TournamentItem>> = tournaments.map { list ->
        list.filter { it.isJoined }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setCategoryFilter(category: TournamentCategory?) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(status: TournamentStatus?) {
        _selectedStatusFilter.value = status
    }

    // --- Actions ---

    fun login(emailOrPhone: String, pass: String) {
        viewModelScope.launch {
            val result = repository.login(emailOrPhone, pass)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success("Welcome back, ${it.username}!"))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Login failed"))
            }
        }
    }

    fun register(name: String, email: String, phone: String, pass: String, refCode: String?) {
        viewModelScope.launch {
            val result = repository.register(name, email, phone, pass, refCode)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success("Account created successfully!"))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Registration failed"))
            }
        }
    }

    fun toggleRole() {
        viewModelScope.launch {
            repository.toggleRole()
            val newRole = repository.currentUser.value?.role
            _uiMessage.emit(UiMessage.Success("Switched to $newRole mode"))
        }
    }

    fun joinTournament(tournamentId: String, ign: String, igid: String) {
        viewModelScope.launch {
            val result = repository.joinTournament(tournamentId, ign, igid)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success(it))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Registration failed"))
            }
        }
    }

    fun addMoney(amountPaise: Long, method: PaymentMethod) {
        viewModelScope.launch {
            val result = repository.addMoney(amountPaise, method)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success(it))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Deposit failed"))
            }
        }
    }

    fun withdrawMoney(amountPaise: Long, method: WithdrawalMethod, destination: String) {
        viewModelScope.launch {
            val result = repository.withdrawMoney(amountPaise, method, destination)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success(it))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Withdrawal failed"))
            }
        }
    }

    fun submitKyc(submission: KycSubmission) {
        viewModelScope.launch {
            val result = repository.submitKyc(submission)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success(it))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "KYC failed"))
            }
        }
    }

    fun claimDailyReward() {
        viewModelScope.launch {
            val result = repository.claimDailyReward()
            result.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
        }
    }

    fun claimTaskReward(taskId: String) {
        viewModelScope.launch {
            val result = repository.claimTaskReward(taskId)
            result.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Could not claim")) }
        }
    }

    // --- Admin Operations ---

    fun adminCreateTournament(
        title: String,
        category: TournamentCategory,
        entryFeeRupees: Long,
        maxSlots: Int,
        matchFormat: MatchFormat,
        mapName: RoomType,
        scheduledHoursFromNow: Int,
        description: String,
        rules: List<String>,
        difficulty: TournamentDifficulty = TournamentDifficulty.NORMAL
    ) {
        viewModelScope.launch {
            val entryFeePaise = MoneyEngine.rupeesToPaise(entryFeeRupees)
            val result = repository.adminCreateTournament(
                title = title,
                category = category,
                entryFeePaise = entryFeePaise,
                maxSlots = maxSlots,
                matchFormat = matchFormat,
                mapName = mapName,
                scheduledHoursFromNow = scheduledHoursFromNow,
                description = description,
                rules = rules,
                difficulty = difficulty
            )
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success("Tournament '${it.title}' published successfully!"))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to create tournament"))
            }
        }
    }

    fun adminCreateTournamentUniversal(tournament: TournamentItem) {
        viewModelScope.launch {
            val result = repository.adminCreateTournamentUniversal(tournament)
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success("Tournament '${it.title}' published successfully!"))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to create tournament"))
            }
        }
    }

    fun adminGenerateTournament(
        mode: ConfigurableGameMode,
        map: ConfigurableGameMap,
        matchFormat: MatchFormat,
        entryFeeRupees: Long,
        slots: Int,
        hoursFromNow: Int,
        formatType: TournamentFormatType = TournamentFormatType.SINGLE_MATCH,
        difficulty: TournamentDifficulty = TournamentDifficulty.NORMAL
    ) {
        viewModelScope.launch {
            val result = repository.adminGenerateTournament(
                mode = mode,
                map = map,
                matchFormat = matchFormat,
                entryFeeRupees = entryFeeRupees,
                slots = slots,
                hoursFromNow = hoursFromNow,
                formatType = formatType,
                difficulty = difficulty
            )
            result.onSuccess {
                _uiMessage.emit(UiMessage.Success("Auto-generated tournament '${it.title}'!"))
            }.onFailure {
                _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to generate tournament"))
            }
        }
    }

    fun adminAddMap(
        name: String,
        modeCategory: TournamentCategory,
        roomType: RoomType,
        supportedFormats: List<MatchFormat>,
        minPlayers: Int,
        maxPlayers: Int,
        description: String = "",
        isEnabled: Boolean = true
    ) {
        viewModelScope.launch {
            val res = repository.adminAddMap(name, modeCategory, roomType, supportedFormats, minPlayers, maxPlayers, description, isEnabled)
            res.onSuccess { _uiMessage.emit(UiMessage.Success("Map '${it.name}' created!")) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to add map")) }
        }
    }

    fun adminUpdateMap(map: ConfigurableGameMap) {
        viewModelScope.launch {
            val res = repository.adminUpdateMap(map)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to update map")) }
        }
    }

    fun adminToggleMap(mapId: String, isEnabled: Boolean) {
        viewModelScope.launch {
            val res = repository.adminToggleMap(mapId, isEnabled)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to toggle map")) }
        }
    }

    fun adminDeleteMap(mapId: String) {
        viewModelScope.launch {
            val res = repository.adminDeleteMap(mapId)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to delete map")) }
        }
    }

    fun adminToggleGameMode(modeId: String, isEnabled: Boolean) {
        viewModelScope.launch {
            val res = repository.adminToggleGameMode(modeId, isEnabled)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Failed to toggle mode")) }
        }
    }

    fun adminUpdateRoom(tournamentId: String, roomId: String, pass: String) {
        viewModelScope.launch {
            val res = repository.adminUpdateRoom(tournamentId, roomId, pass)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Update failed")) }
        }
    }

    fun adminFinalizeResults(tournamentId: String, results: List<MatchResultRecord>) {
        viewModelScope.launch {
            val res = repository.adminFinalizeResults(tournamentId, results)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Finalization failed")) }
        }
    }

    fun adminCancelTournament(tournamentId: String, reason: String) {
        viewModelScope.launch {
            val res = repository.adminCancelTournament(tournamentId, reason)
            res.onSuccess { _uiMessage.emit(UiMessage.Success(it)) }
                .onFailure { _uiMessage.emit(UiMessage.Error(it.message ?: "Cancellation failed")) }
        }
    }
}

class MainViewModelFactory(private val repository: EsportsRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
