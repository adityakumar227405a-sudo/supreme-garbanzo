package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EsportsColorScheme = darkColorScheme(
    primary = EsportsCyan,
    onPrimary = Color.Black,
    primaryContainer = EsportsCyanVariant,
    onPrimaryContainer = Color.White,
    secondary = EsportsCrimson,
    onSecondary = Color.White,
    secondaryContainer = EsportsSurfaceVariant,
    onSecondaryContainer = EsportsCyan,
    tertiary = EsportsGold,
    onTertiary = Color.Black,
    background = EsportsDarkBackground,
    onBackground = TextPrimary,
    surface = EsportsSurface,
    onSurface = TextPrimary,
    surfaceVariant = EsportsSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    outlineVariant = EsportsSurfaceElevated
)

@Composable
fun AdityaBattleTheme(
    darkTheme: Boolean = true, // Mobile esports is dark by design
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EsportsColorScheme,
        typography = Typography,
        content = content
    )
}
