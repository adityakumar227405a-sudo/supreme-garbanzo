package com.example.ui.screens.home

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    banners: List<HomeBanner>,
    tournaments: List<TournamentItem>,
    myTournaments: List<TournamentItem>,
    walletState: WalletState,
    selectedCategory: TournamentCategory?,
    onCategorySelect: (TournamentCategory?) -> Unit,
    onTournamentClick: (TournamentItem) -> Unit,
    onJoinTournamentClick: (TournamentItem) -> Unit,
    onViewAllTournaments: () -> Unit,
    onClaimDailyReward: () -> Unit,
    onTasksClick: () -> Unit,
    onReferralClick: () -> Unit,
    onWalletClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val featuredTournament = tournaments.find { it.status == TournamentStatus.OPEN && !it.isFree }
        ?: tournaments.firstOrNull()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
    ) {
        // Themed Background photo wallpaper
        Image(
            painter = painterResource(id = com.example.R.drawable.bg_esports_home_theme_1787621677774),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = 0.22f,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for contrast and legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            EsportsDarkBackground.copy(alpha = 0.65f),
                            EsportsDarkBackground.copy(alpha = 0.88f),
                            EsportsDarkBackground.copy(alpha = 0.98f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 100.dp) // Space for bottom bar
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Banner Slider
            if (banners.isNotEmpty()) {
                val pagerState = rememberPagerState(pageCount = { banners.size })
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .padding(horizontal = 16.dp)
                ) { page ->
                    val banner = banners[page]
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                        border = BorderStroke(1.dp, CardBorderNeon),
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                banner.targetCategory?.let { onCategorySelect(it) }
                                onViewAllTournaments()
                            }
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Image(
                                painter = painterResource(id = banner.imageRes),
                                contentDescription = banner.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Gradient protection
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(Color.Black.copy(alpha = 0.9f), Color.Transparent)
                                        )
                                    )
                            )

                            Column(
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(16.dp)
                                    .fillMaxWidth(0.75f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (banner.tag.contains("FOUNDER", ignoreCase = true)) EsportsGold else EsportsCrimson
                                ) {
                                    Text(
                                        text = banner.tag,
                                        color = if (banner.tag.contains("FOUNDER", ignoreCase = true)) Color.Black else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = banner.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = banner.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = EsportsGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Pager Dots
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(banners.size) { iteration ->
                        val color = if (pagerState.currentPage == iteration) EsportsCyan else EsportsSurfaceVariant
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .clip(CircleShape)
                                .background(color)
                                .size(if (pagerState.currentPage == iteration) 8.dp else 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Founder & Host Spotlight Banner Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                border = BorderStroke(1.dp, CardBorderGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.banner_aditya_founder_1787621660204),
                        contentDescription = "Aditya Battle Host",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.93f),
                                        Color.Black.copy(alpha = 0.70f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EsportsGold
                                ) {
                                    Text(
                                        text = "HOSTED BY ADITYA",
                                        color = Color.Black,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Filled.Verified,
                                    contentDescription = "Verified",
                                    tint = EsportsCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "100% Fair Play",
                                    color = EsportsCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Daily ₹5, ₹10, ₹20 & Mega Esports Clashes",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = "⚡ 85% Guaranteed Pool Payout • Instant UPI Withdrawal",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = EsportsGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Actions Grid (Daily Streak, Missions, Referrals)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Daily Streak Claim
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorderGold),
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onClaimDailyReward)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(EsportsGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CardGiftcard,
                            contentDescription = "Daily Bonus",
                            tint = EsportsGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Daily Streak",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "+100 Coins",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = EsportsGold
                        )
                    }
                }
            }

            // Referral Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorderNeon),
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onReferralClick)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(EsportsCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = "Referral",
                            tint = EsportsCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Invite & Earn",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "₹50 + Coins",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = EsportsCyan
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- POCKET TOURNAMENTS SECTION (₹5, ₹10, ₹20) ---
        val pocketTournaments = remember(tournaments) {
            tournaments.filter { it.isPocketTournament && it.status == TournamentStatus.OPEN }
        }

        if (pocketTournaments.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = EsportsGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "₹5, ₹10, ₹20 POCKET MATCHES",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        color = EsportsGold
                    )
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EsportsGold.copy(alpha = 0.18f),
                    border = BorderStroke(0.5.dp, EsportsGold)
                ) {
                    Text(
                        text = "85% POOL",
                        color = EsportsGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontal row of pocket tournament cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                pocketTournaments.forEach { tour ->
                    val calculation = MoneyEngine.calculateDistribution(tour.entryFeePaise, tour.maxSlots)
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                        border = BorderStroke(1.dp, CardBorderGold),
                        modifier = Modifier
                            .width(260.dp)
                            .clickable { onTournamentClick(tour) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = EsportsGold,
                                ) {
                                    Text(
                                        text = MoneyEngine.formatRupees(tour.entryFeePaise),
                                        color = Color.Black,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (tour.difficulty) {
                                        TournamentDifficulty.EASY -> Color(0xFF00E676).copy(alpha = 0.18f)
                                        TournamentDifficulty.NORMAL -> EsportsCyan.copy(alpha = 0.18f)
                                        TournamentDifficulty.MEDIUM -> EsportsGold.copy(alpha = 0.18f)
                                        TournamentDifficulty.HARD -> EsportsCrimson.copy(alpha = 0.18f)
                                        TournamentDifficulty.MEGA -> EsportsPurple.copy(alpha = 0.2f)
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        when (tour.difficulty) {
                                            TournamentDifficulty.EASY -> Color(0xFF00E676)
                                            TournamentDifficulty.NORMAL -> EsportsCyan
                                            TournamentDifficulty.MEDIUM -> EsportsGold
                                            TournamentDifficulty.HARD -> EsportsCrimson
                                            TournamentDifficulty.MEGA -> EsportsPurple
                                        }
                                    )
                                ) {
                                    Text(
                                        text = tour.difficulty.displayName.uppercase(),
                                        color = when (tour.difficulty) {
                                            TournamentDifficulty.EASY -> Color(0xFF00E676)
                                            TournamentDifficulty.NORMAL -> EsportsCyan
                                            TournamentDifficulty.MEDIUM -> EsportsGold
                                            TournamentDifficulty.HARD -> EsportsCrimson
                                            TournamentDifficulty.MEGA -> EsportsPurple
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = tour.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "${tour.category.displayName} • ${tour.matchFormat.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(EsportsSurfaceVariant, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "PRIZE POOL",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EsportsGold,
                                        fontSize = 9.sp
                                    )
                                    Text(
                                        text = MoneyEngine.formatRupees(calculation.prizePoolPaise),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = EsportsGold
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "SPOTS LEFT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 9.sp
                                    )
                                    Text(
                                        text = "${tour.remainingSlots} / ${tour.maxSlots}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = EsportsCyan
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { onJoinTournamentClick(tour) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EsportsGold),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "JOIN FOR ${MoneyEngine.formatRupees(tour.entryFeePaise)}",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Categories Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TOURNAMENT MODES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = TextPrimary
            )
            Text(
                text = "See All",
                style = MaterialTheme.typography.bodySmall,
                color = EsportsCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable(onClick = onViewAllTournaments)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Categories Horizontal Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // "ALL" chip
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onCategorySelect(null) },
                label = { Text("All Modes", fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EsportsCyan,
                    selectedLabelColor = Color.Black,
                    containerColor = EsportsSurface,
                    labelColor = TextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedCategory == null,
                    borderColor = CardBorder,
                    selectedBorderColor = EsportsCyan
                )
            )

            TournamentCategory.values().forEach { category ->
                FilterChip(
                    selected = selectedCategory == category,
                    onClick = {
                        onCategorySelect(category)
                        onViewAllTournaments()
                    },
                    label = { Text(category.displayName, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsCyan,
                        selectedLabelColor = Color.Black,
                        containerColor = EsportsSurface,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedCategory == category,
                        borderColor = CardBorder,
                        selectedBorderColor = EsportsCyan
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // If user has joined tournaments, show quick access bar
        if (myTournaments.isNotEmpty()) {
            val nextMatch = myTournaments.first()
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = EsportsSurfaceVariant,
                border = BorderStroke(1.dp, CardBorderCrimson),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onTournamentClick(nextMatch) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(EsportsCrimson),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "YOUR REGISTERED MATCH",
                                style = MaterialTheme.typography.labelSmall,
                                color = EsportsCrimson,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = nextMatch.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "Open",
                        tint = EsportsCyan
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Featured Tournament Card
        if (featuredTournament != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FEATURED TOURNAMENT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = EsportsGold
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EsportsGold.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "80% POOL",
                        color = EsportsGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                TournamentCard(
                    tournament = featuredTournament,
                    onClick = { onTournamentClick(featuredTournament) },
                    onJoinClick = { onJoinTournamentClick(featuredTournament) }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Recent High-Stake Tournaments list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "UPCOMING BATTLES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = TextPrimary
            )
            Text(
                text = "View All (${tournaments.size})",
                style = MaterialTheme.typography.bodySmall,
                color = EsportsCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable(onClick = onViewAllTournaments)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        tournaments.filter { it.id != featuredTournament?.id }.take(3).forEach { tournament ->
            Box(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                TournamentCard(
                    tournament = tournament,
                    onClick = { onTournamentClick(tournament) },
                    onJoinClick = { onJoinTournamentClick(tournament) }
                )
            }
        }
    }
}
}
