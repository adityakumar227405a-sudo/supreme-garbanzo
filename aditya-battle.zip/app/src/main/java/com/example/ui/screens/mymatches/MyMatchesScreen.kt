package com.example.ui.screens.mymatches

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.components.RoomInfoCard
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun MyMatchesScreen(
    tournaments: List<TournamentItem>,
    matchResults: Map<String, List<MatchResultRecord>>,
    onTournamentClick: (TournamentItem) -> Unit,
    onExploreTournaments: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("REGISTERED", "LIVE", "COMPLETED")

    val myMatches = remember(tournaments) {
        tournaments.filter { it.isJoined }
    }

    val displayMatches = remember(myMatches, tournaments, selectedTab) {
        when (selectedTab) {
            0 -> myMatches.filter { it.status == TournamentStatus.OPEN || it.status == TournamentStatus.FULL || it.status == TournamentStatus.UPCOMING }
            1 -> tournaments.filter { it.status == TournamentStatus.LIVE }
            2 -> tournaments.filter { it.status == TournamentStatus.COMPLETED }
            else -> myMatches
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
    ) {
        // Tab Header
        Surface(
            color = EsportsSurface,
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = EsportsSurface,
                contentColor = EsportsCyan,
                divider = {}
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Black else FontWeight.Normal,
                                color = if (selectedTab == index) EsportsCyan else TextSecondary
                            )
                        }
                    )
                }
            }
        }

        if (displayMatches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.SportsEsports,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = when (selectedTab) {
                            0 -> "No Registered Matches Yet"
                            1 -> "No Live Matches Right Now"
                            else -> "No Completed Matches"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Join open tournaments to compete for real prize pools and rankings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onExploreTournaments,
                        colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("EXPLORE TOURNAMENTS", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(displayMatches, key = { it.id }) { match ->
                    Column {
                        TournamentCard(
                            tournament = match,
                            onClick = { onTournamentClick(match) },
                            onJoinClick = { onTournamentClick(match) }
                        )

                        // If user joined this match and room info is available, display room credentials
                        if (match.isJoined || selectedTab == 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            RoomInfoCard(
                                roomId = match.roomId,
                                roomPassword = match.roomPassword,
                                roomReleaseTime = match.roomReleaseTime
                            )
                        }

                        // If completed, show final scorecard summary
                        val results = matchResults[match.id]
                        if (results != null && results.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = EsportsSurfaceVariant,
                                border = BorderStroke(1.dp, CardBorderGold),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "FINAL MATCH LEADERBOARD",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = EsportsGold
                                        )
                                        Text(
                                            text = "Official Scorecard",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    results.forEach { res ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "#${res.rank}",
                                                    fontWeight = FontWeight.Black,
                                                    color = if (res.rank == 1) EsportsGold else TextSecondary,
                                                    modifier = Modifier.width(28.dp)
                                                )
                                                Column {
                                                    Text(
                                                        text = res.username,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextPrimary
                                                    )
                                                    Text(
                                                        text = "IGN: ${res.inGameName} • ${res.kills} Kills",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = TextSecondary
                                                    )
                                                }
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = MoneyEngine.formatRupees(res.prizePaise),
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EsportsGold
                                                )
                                                Text(
                                                    text = "${res.totalPoints} pts",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = EsportsCyan
                                                )
                                            }
                                        }
                                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
