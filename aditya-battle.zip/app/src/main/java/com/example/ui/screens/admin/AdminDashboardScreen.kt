package com.example.ui.screens.admin

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.components.FinancialPreviewCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminDashboardScreen(
    tournaments: List<TournamentItem>,
    auditLogs: List<AuditLogEntry>,
    gameModes: List<ConfigurableGameMode> = emptyList(),
    gameMaps: List<ConfigurableGameMap> = emptyList(),
    onBackClick: () -> Unit,
    onCreateTournament: (
        title: String,
        category: TournamentCategory,
        entryFeeRupees: Long,
        maxSlots: Int,
        matchFormat: MatchFormat,
        mapName: RoomType,
        scheduledHoursFromNow: Int,
        description: String,
        rules: List<String>,
        difficulty: TournamentDifficulty
    ) -> Unit,
    onCreateTournamentUniversal: (tournament: TournamentItem) -> Unit = {},
    onGenerateTournament: (
        mode: ConfigurableGameMode,
        map: ConfigurableGameMap,
        matchFormat: MatchFormat,
        entryFeeRupees: Long,
        slots: Int,
        hoursFromNow: Int,
        formatType: TournamentFormatType,
        difficulty: TournamentDifficulty
    ) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onAddMap: (
        name: String,
        modeCategory: TournamentCategory,
        roomType: RoomType,
        supportedFormats: List<MatchFormat>,
        minPlayers: Int,
        maxPlayers: Int,
        description: String,
        isEnabled: Boolean
    ) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onUpdateMap: (map: ConfigurableGameMap) -> Unit = {},
    onToggleMap: (mapId: String, isEnabled: Boolean) -> Unit = { _, _ -> },
    onDeleteMap: (mapId: String) -> Unit = {},
    onToggleGameMode: (modeId: String, isEnabled: Boolean) -> Unit = { _, _ -> },
    onUpdateRoom: (tournamentId: String, roomId: String, pass: String) -> Unit,
    onFinalizeResults: (tournamentId: String, results: List<MatchResultRecord>) -> Unit,
    onCancelTournament: (tournamentId: String, reason: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf(
        "OVERVIEW",
        "TOURNAMENT BUILDER",
        "MAP MANAGER",
        "MODE MANAGER",
        "ROOM DISPATCH",
        "FINALIZE RESULTS",
        "AUDIT LOGS"
    )

    Scaffold(
        topBar = {
            Surface(
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Admin Control Center",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = EsportsCrimson
                        )
                        Text(
                            text = "Universal Tournament & Map Engine",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(EsportsDarkBackground)
                .padding(innerPadding)
        ) {
            // Scrollable Admin Tab Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = EsportsSurface,
                contentColor = EsportsCrimson,
                edgePadding = 16.dp,
                divider = {}
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) EsportsCrimson else TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> AdminOverviewTab(tournaments = tournaments)
                1 -> UniversalTournamentBuilderTab(
                    gameModes = gameModes,
                    gameMaps = gameMaps,
                    onCreateUniversal = onCreateTournamentUniversal,
                    onGenerate = onGenerateTournament
                )
                2 -> AdminMapManagerTab(
                    gameMaps = gameMaps,
                    onAddMap = onAddMap,
                    onUpdateMap = onUpdateMap,
                    onToggleMap = onToggleMap,
                    onDeleteMap = onDeleteMap
                )
                3 -> AdminModeManagerTab(
                    gameModes = gameModes,
                    onToggleGameMode = onToggleGameMode
                )
                4 -> AdminRoomDispatchTab(tournaments = tournaments, onUpdateRoom = onUpdateRoom)
                5 -> AdminFinalizeResultsTab(tournaments = tournaments, onFinalize = onFinalizeResults)
                6 -> AdminAuditLogsTab(auditLogs = auditLogs)
            }
        }
    }
}

@Composable
private fun AdminOverviewTab(tournaments: List<TournamentItem>) {
    val totalTurnoverPaise = tournaments.sumOf { it.entryFeePaise * it.filledSlots }
    val totalPlatformSharePaise = tournaments.sumOf {
        val calc = MoneyEngine.calculateDistribution(it.entryFeePaise, it.maxSlots)
        if (it.maxSlots > 0) (calc.platformSharePaise * it.filledSlots) / it.maxSlots else 0L
    }
    val totalPrizeDistributedPaise = totalTurnoverPaise - totalPlatformSharePaise

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "PLATFORM FINANCIAL OVERVIEW",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = EsportsGold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Turnover Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = EsportsSurface,
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "TOTAL GROSS TURNOVER", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = MoneyEngine.formatRupees(totalTurnoverPaise),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    color = EsportsCyan
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Total Active Tournaments: ${tournaments.size} | Total Confirmed Players: ${tournaments.sumOf { it.filledSlots }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorderNeon),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Owner Commission", style = MaterialTheme.typography.labelSmall, color = EsportsCyan)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = MoneyEngine.formatRupees(totalPlatformSharePaise),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = EsportsCyan
                    )
                    Text(text = "15% (₹1-100) / 20% (₹101-10k)", style = MaterialTheme.typography.bodySmall, color = TextTertiary, fontSize = 10.sp)
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorderGold),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Prize Disbursed", style = MaterialTheme.typography.labelSmall, color = EsportsGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = MoneyEngine.formatRupees(totalPrizeDistributedPaise),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = EsportsGold
                    )
                    Text(text = "85% (₹1-100) / 80% (₹101-10k)", style = MaterialTheme.typography.bodySmall, color = TextTertiary, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "ACTIVE TOURNAMENT MONITORS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        tournaments.forEach { tour ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = tour.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            text = "${tour.category.displayName} • ${tour.matchFormat.label} • ${tour.filledSlots}/${tour.maxSlots} Slots • Fee: ${MoneyEngine.formatRupees(tour.entryFeePaise)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EsportsSurfaceElevated
                    ) {
                        Text(
                            text = tour.status.label,
                            color = EsportsCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UniversalTournamentBuilderTab(
    gameModes: List<ConfigurableGameMode>,
    gameMaps: List<ConfigurableGameMap>,
    onCreateUniversal: (tournament: TournamentItem) -> Unit,
    onGenerate: (
        mode: ConfigurableGameMode,
        map: ConfigurableGameMap,
        matchFormat: MatchFormat,
        entryFeeRupees: Long,
        slots: Int,
        hoursFromNow: Int,
        formatType: TournamentFormatType,
        difficulty: TournamentDifficulty
    ) -> Unit
) {
    val enabledModes = gameModes.filter { it.isEnabled }.ifEmpty {
        listOf(
            ConfigurableGameMode("br_solo", "BR Solo", TournamentCategory.BATTLE_ROYALE, defaultMatchFormat = MatchFormat.SOLO),
            ConfigurableGameMode("cs_4v4", "Clash Squad 4v4", TournamentCategory.CLASH_SQUAD, defaultMatchFormat = MatchFormat.CLASH_4V4),
            ConfigurableGameMode("lw_1v1", "Lone Wolf 1v1", TournamentCategory.LONE_WOLF, defaultMatchFormat = MatchFormat.LONE_WOLF_1V1)
        )
    }
    val enabledMaps = gameMaps.filter { it.isEnabled }.ifEmpty {
        listOf(
            ConfigurableGameMap("map_bermuda", "Bermuda Classic", TournamentCategory.BATTLE_ROYALE, RoomType.CLASSIC_BERMUDA),
            ConfigurableGameMap("map_purgatory", "Purgatory", TournamentCategory.BATTLE_ROYALE, RoomType.PURGATORY),
            ConfigurableGameMap("map_kalahari", "Kalahari Desert", TournamentCategory.BATTLE_ROYALE, RoomType.KALAHARI)
        )
    }

    var selectedMode by remember { mutableStateOf(enabledModes.first()) }
    var selectedMap by remember { mutableStateOf(enabledMaps.first()) }
    var selectedFormat by remember { mutableStateOf(selectedMode.defaultMatchFormat) }
    var selectedFormatType by remember { mutableStateOf(TournamentFormatType.SINGLE_MATCH) }
    var selectedDifficulty by remember { mutableStateOf(TournamentDifficulty.NORMAL) }
    var entryFeeInput by remember { mutableStateOf("10") }
    var slotsInput by remember { mutableStateOf("48") }
    var startsInHoursInput by remember { mutableStateOf("2") }
    var customTitleInput by remember { mutableStateOf("") }
    var customDescInput by remember { mutableStateOf("") }
    var isAdvancedCustom by remember { mutableStateOf(false) }

    val feeRupees = entryFeeInput.toLongOrNull() ?: 0L
    val feePaise = MoneyEngine.rupeesToPaise(feeRupees)
    val maxSlots = slotsInput.toIntOrNull() ?: 48
    val calculation = MoneyEngine.calculateDistribution(feePaise, maxSlots)

    // Auto-update match format when mode changes
    LaunchedEffect(selectedMode) {
        selectedFormat = selectedMode.defaultMatchFormat
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "UNIVERSAL TOURNAMENT BUILDER",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = EsportsCrimson
        )
        Text(
            text = "Create or auto-generate any game mode, map, format, and fee structure without code changes.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Step 1: Select Game Mode
        Text(text = "1. SELECT GAME MODE (${enabledModes.size} active)", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            enabledModes.forEach { mode ->
                FilterChip(
                    selected = selectedMode.id == mode.id,
                    onClick = { selectedMode = mode },
                    label = { Text(mode.name, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsCrimson,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step 2: Select Game Map
        Text(text = "2. SELECT BATTLE MAP (${enabledMaps.size} active)", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            enabledMaps.forEach { map ->
                FilterChip(
                    selected = selectedMap.id == map.id,
                    onClick = { selectedMap = map },
                    label = { Text(map.name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsPurple,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step 3: Match Format (Solo / Duo / Squad / Clash / Lone Wolf)
        Text(text = "3. TEAM / MATCH FORMAT", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MatchFormat.values().forEach { format ->
                FilterChip(
                    selected = selectedFormat == format,
                    onClick = { selectedFormat = format },
                    label = { Text(format.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsGold,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step 4: Tournament Format Type
        Text(text = "4. TOURNAMENT BRACKET / FORMAT", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TournamentFormatType.values().forEach { fType ->
                FilterChip(
                    selected = selectedFormatType == fType,
                    onClick = { selectedFormatType = fType },
                    label = { Text(fType.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsSurfaceElevated,
                        selectedLabelColor = EsportsCyan
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step 5: Quick Entry Fee Presets
        Text(text = "5. ENTRY FEE PRESETS (Free, Pocket ₹5–₹100, High ₹101–₹10,000)", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(0L, 5L, 10L, 20L, 30L, 50L, 100L, 200L, 500L, 1000L, 5000L, 10000L).forEach { presetFee ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (entryFeeInput == presetFee.toString()) EsportsGold else EsportsSurfaceElevated,
                    border = BorderStroke(1.dp, if (entryFeeInput == presetFee.toString()) EsportsGold else CardBorder),
                    modifier = Modifier.clickable { entryFeeInput = presetFee.toString() }
                ) {
                    Text(
                        text = if (presetFee == 0L) "FREE" else "₹$presetFee",
                        color = if (entryFeeInput == presetFee.toString()) Color.Black else TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = entryFeeInput,
                onValueChange = { entryFeeInput = it },
                label = { Text("Entry Fee (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
                value = slotsInput,
                onValueChange = { slotsInput = it },
                label = { Text("Max Slots") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
                value = startsInHoursInput,
                onValueChange = { startsInHoursInput = it },
                label = { Text("Starts In (Hrs)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step 6: Difficulty Selector
        Text(text = "6. DIFFICULTY TIER", style = MaterialTheme.typography.labelSmall, color = EsportsCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TournamentDifficulty.values().forEach { diff ->
                FilterChip(
                    selected = selectedDifficulty == diff,
                    onClick = { selectedDifficulty = diff },
                    label = { Text(diff.displayName) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EsportsCrimson,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Optional Custom Title & Description
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Custom Title / Overrides", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Switch(
                checked = isAdvancedCustom,
                onCheckedChange = { isAdvancedCustom = it },
                colors = SwitchDefaults.colors(checkedThumbColor = EsportsCyan)
            )
        }

        if (isAdvancedCustom) {
            OutlinedTextField(
                value = customTitleInput,
                onValueChange = { customTitleInput = it },
                label = { Text("Custom Title (Optional)") },
                placeholder = { Text("e.g. ₹50 Aditya Clash Masters") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = customDescInput,
                onValueChange = { customDescInput = it },
                label = { Text("Custom Description") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Dynamic Mathematical Financial Preview Card
        FinancialPreviewCard(calculation = calculation)

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons: Quick Auto-Generate OR Universal Publish
        Button(
            onClick = {
                if (isAdvancedCustom && customTitleInput.isNotBlank()) {
                    val tier = when {
                        feeRupees == 0L -> TournamentTierType.FREE
                        feeRupees <= 100L -> TournamentTierType.LOW_ENTRY
                        feeRupees <= 1000L -> TournamentTierType.MEDIUM_ENTRY
                        else -> TournamentTierType.HIGH_ENTRY
                    }
                    val item = TournamentItem(
                        id = "tour_${UUID.randomUUID().toString().take(8)}",
                        title = customTitleInput.trim(),
                        category = selectedMode.parentCategory,
                        entryFeePaise = feePaise,
                        maxSlots = maxSlots,
                        filledSlots = 0,
                        matchFormat = selectedFormat,
                        mapName = selectedMap.roomType,
                        scheduledTimeEpoch = System.currentTimeMillis() + (startsInHoursInput.toIntOrNull() ?: 2) * 3600000L,
                        status = TournamentStatus.OPEN,
                        description = customDescInput.ifBlank { "Universal tournament for ${selectedMode.name} on ${selectedMap.name}." },
                        rules = listOf(
                            "Mode: ${selectedMode.name} (${selectedFormat.label})",
                            "Map: ${selectedMap.name}",
                            "Format: ${selectedFormatType.label}",
                            "Fair play guaranteed."
                        ),
                        difficulty = selectedDifficulty,
                        formatType = selectedFormatType,
                        tierType = tier,
                        gameModeName = selectedMode.name,
                        customBannerRes = selectedMap.customImageRes
                    )
                    onCreateUniversal(item)
                } else {
                    onGenerate(
                        selectedMode,
                        selectedMap,
                        selectedFormat,
                        feeRupees,
                        maxSlots,
                        startsInHoursInput.toIntOrNull() ?: 2,
                        selectedFormatType,
                        selectedDifficulty
                    )
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EsportsCrimson),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("universal_publish_tournament_button")
        ) {
            Icon(Icons.Filled.Bolt, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("GENERATE & PUBLISH TOURNAMENT", color = Color.White, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun AdminMapManagerTab(
    gameMaps: List<ConfigurableGameMap>,
    onAddMap: (
        name: String,
        modeCategory: TournamentCategory,
        roomType: RoomType,
        supportedFormats: List<MatchFormat>,
        minPlayers: Int,
        maxPlayers: Int,
        description: String,
        isEnabled: Boolean
    ) -> Unit,
    onUpdateMap: (map: ConfigurableGameMap) -> Unit,
    onToggleMap: (mapId: String, isEnabled: Boolean) -> Unit,
    onDeleteMap: (mapId: String) -> Unit
) {
    var showAddMapDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DYNAMIC MAP MANAGEMENT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = EsportsPurple
                )
                Text(
                    text = "Configure battlegrounds, player capacities, and mode bindings",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = { showAddMapDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = EsportsPurple),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ADD MAP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        gameMaps.forEach { map ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, if (map.isEnabled) CardBorderNeon else CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = map.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (map.isEnabled) Color(0xFF00E676).copy(alpha = 0.2f) else Color.Red.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = if (map.isEnabled) "ACTIVE" else "DISABLED",
                                        color = if (map.isEnabled) Color(0xFF00E676) else Color.Red,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Category: ${map.modeCategory.displayName} • Room: ${map.roomType.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = EsportsCyan,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = map.isEnabled,
                            onCheckedChange = { onToggleMap(map.id, it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = EsportsCyan)
                        )
                    }

                    if (map.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = map.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Players: ${map.minPlayers}–${map.maxPlayers} • Formats: ${map.supportedFormats.joinToString { it.label }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary,
                            fontSize = 10.sp
                        )

                        IconButton(
                            onClick = { onDeleteMap(map.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = TextTertiary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (showAddMapDialog) {
        var mapName by remember { mutableStateOf("") }
        var mapCategory by remember { mutableStateOf(TournamentCategory.BATTLE_ROYALE) }
        var mapRoomType by remember { mutableStateOf(RoomType.CUSTOM_MAP) }
        var minPlayersInput by remember { mutableStateOf("2") }
        var maxPlayersInput by remember { mutableStateOf("48") }
        var descriptionInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddMapDialog = false },
            title = { Text("Add New Battleground Map", color = EsportsPurple, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = mapName,
                        onValueChange = { mapName = it },
                        label = { Text("Map Name") },
                        placeholder = { Text("e.g. Bermuda 2.0 / Iron Cage") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Target Mode Category:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TournamentCategory.values().forEach { cat ->
                            FilterChip(
                                selected = mapCategory == cat,
                                onClick = { mapCategory = cat },
                                label = { Text(cat.displayName, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = minPlayersInput,
                            onValueChange = { minPlayersInput = it },
                            label = { Text("Min Players") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = maxPlayersInput,
                            onValueChange = { maxPlayersInput = it },
                            label = { Text("Max Players") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = descriptionInput,
                        onValueChange = { descriptionInput = it },
                        label = { Text("Description / Map Features") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (mapName.isNotBlank()) {
                            onAddMap(
                                mapName.trim(),
                                mapCategory,
                                mapRoomType,
                                listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
                                minPlayersInput.toIntOrNull() ?: 2,
                                maxPlayersInput.toIntOrNull() ?: 48,
                                descriptionInput.trim(),
                                true
                            )
                            showAddMapDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsPurple)
                ) {
                    Text("SAVE MAP")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMapDialog = false }) {
                    Text("CANCEL", color = TextSecondary)
                }
            },
            containerColor = EsportsSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun AdminModeManagerTab(
    gameModes: List<ConfigurableGameMode>,
    onToggleGameMode: (modeId: String, isEnabled: Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "DYNAMIC GAME MODE MANAGER",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = EsportsGold
        )
        Text(
            text = "Enable or disable any category mode across the application in real-time.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        gameModes.forEach { mode ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, if (mode.isEnabled) CardBorderGold else CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = mode.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (mode.isRanked) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EsportsGold.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "RANKED",
                                        color = EsportsGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${mode.parentCategory.displayName} • Format: ${mode.defaultMatchFormat.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = EsportsCyan,
                            fontSize = 11.sp
                        )
                        if (mode.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = mode.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
                        }
                    }

                    Switch(
                        checked = mode.isEnabled,
                        onCheckedChange = { onToggleGameMode(mode.id, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = EsportsGold)
                    )
                }
            }
        }
    }
}

@Composable
private fun AdminRoomDispatchTab(
    tournaments: List<TournamentItem>,
    onUpdateRoom: (tournamentId: String, roomId: String, pass: String) -> Unit
) {
    val activeTournaments = tournaments.filter { it.status != TournamentStatus.COMPLETED && it.status != TournamentStatus.CANCELLED }
    var selectedTourId by remember { mutableStateOf(activeTournaments.firstOrNull()?.id ?: "") }
    var roomIdInput by remember { mutableStateOf("9928104") }
    var passwordInput by remember { mutableStateOf("FIGHT99") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "DISPATCH ROOM CREDENTIALS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = EsportsCyan
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(text = "Select Tournament to Dispatch Room:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))

        activeTournaments.forEach { tour ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (selectedTourId == tour.id) EsportsSurfaceElevated else EsportsSurface,
                border = BorderStroke(
                    1.dp,
                    if (selectedTourId == tour.id) EsportsCyan else CardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable { selectedTourId = tour.id }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedTourId == tour.id,
                        onClick = { selectedTourId = tour.id },
                        colors = RadioButtonDefaults.colors(selectedColor = EsportsCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(text = tour.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(text = "Filled: ${tour.filledSlots}/${tour.maxSlots} Players • Status: ${tour.status.label}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = roomIdInput,
            onValueChange = { roomIdInput = it },
            label = { Text("Game Custom Room ID") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            label = { Text("Room Password") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onUpdateRoom(selectedTourId, roomIdInput, passwordInput) },
            enabled = selectedTourId.isNotBlank() && roomIdInput.isNotBlank() && passwordInput.isNotBlank(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Filled.Send, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(8.dp))
            Text("NOTIFY PLAYERS & UNLOCK ROOM", color = Color.Black, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun AdminFinalizeResultsTab(
    tournaments: List<TournamentItem>,
    onFinalize: (tournamentId: String, results: List<MatchResultRecord>) -> Unit
) {
    val pendingTournaments = tournaments.filter { it.status != TournamentStatus.COMPLETED && it.status != TournamentStatus.CANCELLED }
    var selectedTourId by remember { mutableStateOf(pendingTournaments.firstOrNull()?.id ?: "") }

    val currentTournament = tournaments.find { it.id == selectedTourId }
    val calculation = currentTournament?.let {
        MoneyEngine.calculateDistribution(it.entryFeePaise, it.maxSlots)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "FINALIZE MATCH & PAYOUT PRIZES",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = EsportsGold
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(text = "Select Tournament to Finalize:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))

        pendingTournaments.forEach { tour ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (selectedTourId == tour.id) EsportsSurfaceElevated else EsportsSurface,
                border = BorderStroke(
                    1.dp,
                    if (selectedTourId == tour.id) EsportsGold else CardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable { selectedTourId = tour.id }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedTourId == tour.id,
                        onClick = { selectedTourId = tour.id },
                        colors = RadioButtonDefaults.colors(selectedColor = EsportsGold)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = tour.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (calculation != null) {
            Text(
                text = "Auto-Calculated Winner Payout Schedule (85%/80% Rule)",
                style = MaterialTheme.typography.labelSmall,
                color = EsportsGold
            )

            Spacer(modifier = Modifier.height(6.dp))

            calculation.rankPrizesPaise.forEach { rankPrize ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EsportsSurface, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = rankPrize.rankLabel, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Text(text = MoneyEngine.formatRupees(rankPrize.prizePaise), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EsportsGold)
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val sampleResults = listOf(
                        MatchResultRecord(
                            id = "res_${UUID.randomUUID().toString().take(6)}",
                            tournamentId = selectedTourId,
                            userId = "user_aditya_01",
                            username = "AdityaWarrior",
                            inGameName = "ShadowHunter",
                            kills = 8,
                            placement = 1,
                            killPoints = 80,
                            placementPoints = 100,
                            bonusPoints = 20,
                            totalPoints = 200,
                            rank = 1,
                            prizePaise = calculation.rankPrizesPaise.getOrNull(0)?.prizePaise ?: 0L
                        ),
                        MatchResultRecord(
                            id = "res_${UUID.randomUUID().toString().take(6)}",
                            tournamentId = selectedTourId,
                            userId = "user_02",
                            username = "ViperStrike",
                            inGameName = "ViperX",
                            kills = 5,
                            placement = 2,
                            killPoints = 50,
                            placementPoints = 75,
                            bonusPoints = 0,
                            totalPoints = 125,
                            rank = 2,
                            prizePaise = calculation.rankPrizesPaise.getOrNull(1)?.prizePaise ?: 0L
                        )
                    )
                    onFinalize(selectedTourId, sampleResults)
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EsportsGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("FINALIZE RESULTS & CREDIT PRIZES", color = Color.Black, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun AdminAuditLogsTab(auditLogs: List<AuditLogEntry>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(auditLogs, key = { it.id }) { log ->
            val dateStr = remember(log.timestamp) {
                SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault()).format(Date(log.timestamp))
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = log.action, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EsportsCyan)
                        Text(text = dateStr, style = MaterialTheme.typography.bodySmall, color = TextTertiary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = log.details, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = "By: ${log.adminName} • Target: ${log.target}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
                }
            }
        }
    }
}
