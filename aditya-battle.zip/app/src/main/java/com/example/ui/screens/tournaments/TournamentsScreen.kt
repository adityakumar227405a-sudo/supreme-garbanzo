package com.example.ui.screens.tournaments

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

enum class TournamentSortOption(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    TIME("Start Time", Icons.Filled.Schedule),
    PRIZE_HIGH("Highest Prize", Icons.Filled.EmojiEvents),
    FEE_LOW("Lowest Fee", Icons.Filled.Savings),
    SLOTS_OPEN("Most Spots", Icons.Filled.PeopleAlt)
}

@Composable
fun TournamentsScreen(
    tournaments: List<TournamentItem>,
    selectedCategory: TournamentCategory?,
    searchQuery: String,
    selectedStatus: TournamentStatus?,
    onCategorySelect: (TournamentCategory?) -> Unit,
    onSearchChange: (String) -> Unit,
    onStatusSelect: (TournamentStatus?) -> Unit,
    onTournamentClick: (TournamentItem) -> Unit,
    onJoinTournamentClick: (TournamentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFeeTier by remember { mutableStateOf<String?>("ALL") }
    var selectedDifficulty by remember { mutableStateOf<TournamentDifficulty?>(null) }
    var selectedSort by remember { mutableStateOf(TournamentSortOption.TIME) }

    // Dynamic Filtered & Sorted Tournament List
    val filteredTournaments = remember(
        tournaments,
        selectedFeeTier,
        selectedDifficulty,
        selectedCategory,
        selectedStatus,
        searchQuery,
        selectedSort
    ) {
        val filtered = tournaments.filter { item ->
            // Category filter
            val matchesCategory = selectedCategory == null || item.category == selectedCategory

            // Status filter
            val matchesStatus = selectedStatus == null || item.status == selectedStatus

            // Search filter
            val matchesSearch = searchQuery.isBlank() ||
                    item.title.contains(searchQuery, ignoreCase = true) ||
                    item.mapName.label.contains(searchQuery, ignoreCase = true) ||
                    item.matchFormat.label.contains(searchQuery, ignoreCase = true) ||
                    item.difficulty.displayName.contains(searchQuery, ignoreCase = true)

            // Fee filter
            val matchesFee = when (selectedFeeTier) {
                "POCKET" -> item.isPocketTournament // ₹5, ₹10, ₹20
                "FREE" -> item.isFree
                "NORMAL_MID" -> item.entryFeePaise in 3000L..10000L // ₹30 - ₹100
                "MEGA_HIGH" -> item.entryFeePaise > 10000L // ₹100+
                else -> true
            }

            // Difficulty filter
            val matchesDifficulty = selectedDifficulty == null || item.difficulty == selectedDifficulty

            matchesCategory && matchesStatus && matchesSearch && matchesFee && matchesDifficulty
        }

        // Apply Sorting
        when (selectedSort) {
            TournamentSortOption.TIME -> filtered.sortedBy { it.scheduledTimeEpoch }
            TournamentSortOption.PRIZE_HIGH -> filtered.sortedByDescending { it.entryFeePaise * it.maxSlots }
            TournamentSortOption.FEE_LOW -> filtered.sortedBy { it.entryFeePaise }
            TournamentSortOption.SLOTS_OPEN -> filtered.sortedByDescending { it.remainingSlots }
        }
    }

    val hasActiveFilters = selectedCategory != null ||
            selectedStatus != null ||
            selectedFeeTier != "ALL" ||
            selectedDifficulty != null ||
            searchQuery.isNotBlank()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
    ) {
        // Search & Filter Header
        Surface(
            color = EsportsSurface,
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search tournaments, ₹5/₹10/₹20, CS, BR...", color = TextTertiary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = EsportsCyan) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear", tint = TextSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedContainerColor = EsportsDarkBackground,
                        unfocusedContainerColor = EsportsDarkBackground
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Fee Tier Quick Selector
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(end = 8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedFeeTier == "ALL",
                            onClick = { selectedFeeTier = "ALL" },
                            label = { Text("All Fees", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedFeeTier == "POCKET",
                            onClick = { selectedFeeTier = if (selectedFeeTier == "POCKET") "ALL" else "POCKET" },
                            label = { Text("⚡ Pocket ₹5, ₹10, ₹20", fontWeight = FontWeight.Black, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsGold,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedFeeTier == "FREE",
                            onClick = { selectedFeeTier = if (selectedFeeTier == "FREE") "ALL" else "FREE" },
                            label = { Text("Free Practice (₹0)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsGreen,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedFeeTier == "NORMAL_MID",
                            onClick = { selectedFeeTier = if (selectedFeeTier == "NORMAL_MID") "ALL" else "NORMAL_MID" },
                            label = { Text("₹30 - ₹100 Normal", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedFeeTier == "MEGA_HIGH",
                            onClick = { selectedFeeTier = if (selectedFeeTier == "MEGA_HIGH") "ALL" else "MEGA_HIGH" },
                            label = { Text("Mega Grand (₹100+)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsPurple,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Match Status Filters (All, Open, Live, Upcoming, Completed)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(end = 8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedStatus == null,
                            onClick = { onStatusSelect(null) },
                            label = { Text("All Status", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsSurfaceElevated,
                                selectedLabelColor = EsportsCyan
                            )
                        )
                    }
                    items(TournamentStatus.values()) { status ->
                        val isSelected = selectedStatus == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { onStatusSelect(if (isSelected) null else status) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (status == TournamentStatus.LIVE) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(EsportsCrimson)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = status.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                                    )
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = when (status) {
                                    TournamentStatus.LIVE -> EsportsCrimson
                                    TournamentStatus.OPEN -> EsportsGreen
                                    TournamentStatus.COMPLETED -> EsportsSurfaceVariant
                                    else -> EsportsSurfaceElevated
                                },
                                selectedLabelColor = if (status == TournamentStatus.LIVE) Color.White else if (status == TournamentStatus.OPEN) Color.Black else EsportsCyan
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Game Mode / Category Filters
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(end = 8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { onCategorySelect(null) },
                            label = { Text("All Modes", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsSurfaceElevated,
                                selectedLabelColor = EsportsCyan
                            )
                        )
                    }
                    items(TournamentCategory.values()) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { onCategorySelect(if (selectedCategory == category) null else category) },
                            label = { Text(category.displayName, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsSurfaceElevated,
                                selectedLabelColor = EsportsCyan
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Active Summary Bar & Sorting Options
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${filteredTournaments.size} tournaments available",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = EsportsCyan
                        )
                        if (hasActiveFilters) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Reset",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = EsportsCrimson,
                                modifier = Modifier
                                    .clickable {
                                        onCategorySelect(null)
                                        onStatusSelect(null)
                                        onSearchChange("")
                                        selectedFeeTier = "ALL"
                                        selectedDifficulty = null
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }

                    // Sort Selector
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TournamentSortOption.values().forEach { sortOpt ->
                            val isSelected = selectedSort == sortOpt
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) EsportsCyan.copy(alpha = 0.2f) else EsportsDarkBackground,
                                border = BorderStroke(0.5.dp, if (isSelected) EsportsCyan else CardBorder),
                                modifier = Modifier.clickable { selectedSort = sortOpt }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = sortOpt.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) EsportsCyan else TextTertiary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = sortOpt.label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                        color = if (isSelected) EsportsCyan else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Tournaments List
        if (filteredTournaments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.SportsEsports,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "No Tournaments Found",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Try clearing your search or selecting a different fee/difficulty tier.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            onCategorySelect(null)
                            onStatusSelect(null)
                            onSearchChange("")
                            selectedFeeTier = "ALL"
                            selectedDifficulty = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Reset All Filters", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredTournaments, key = { it.id }) { tournament ->
                    TournamentCard(
                        tournament = tournament,
                        onClick = { onTournamentClick(tournament) },
                        onJoinClick = { onJoinTournamentClick(tournament) }
                    )
                }
            }
        }
    }
}
