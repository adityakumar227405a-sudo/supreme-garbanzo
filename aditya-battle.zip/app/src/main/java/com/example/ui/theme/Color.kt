package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Esports Theme Palette - Neon & Dark Onyx
val EsportsDarkBackground = Color(0xFF090D16)
val EsportsSurface = Color(0xFF111827)
val EsportsSurfaceVariant = Color(0xFF1A2333)
val EsportsSurfaceElevated = Color(0xFF232F46)

val EsportsCyan = Color(0xFF00E5FF)
val EsportsCyanVariant = Color(0xFF00B0FF)
val EsportsCrimson = Color(0xFFFF2A55)
val EsportsGold = Color(0xFFFFD700)
val EsportsGreen = Color(0xFF00E676)
val EsportsPurple = Color(0xFF7C4DFF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val CardBorder = Color(0xFF1E293B)
val CardBorderNeon = Color(0x6600E5FF)
val CardBorderCrimson = Color(0x66FF2A55)
val CardBorderGold = Color(0x66FFD700)
