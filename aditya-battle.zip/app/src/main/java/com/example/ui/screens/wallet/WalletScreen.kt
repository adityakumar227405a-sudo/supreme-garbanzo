package com.example.ui.screens.wallet

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WalletScreen(
    walletState: WalletState,
    transactions: List<WalletTransactionRecord>,
    userProfile: UserProfile?,
    onAddMoney: (amountPaise: Long, method: PaymentMethod) -> Unit,
    onWithdrawMoney: (amountPaise: Long, method: WithdrawalMethod, destination: String) -> Unit,
    onStartKyc: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddMoneyDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }
    var selectedTxFilter by remember { mutableStateOf<TransactionType?>(null) }

    val filteredTransactions = remember(transactions, selectedTxFilter) {
        if (selectedTxFilter == null) transactions
        else transactions.filter { it.type == selectedTxFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
    ) {
        // Main Wallet Hero Card
        Surface(
            color = EsportsSurface,
            border = BorderStroke(1.dp, CardBorderNeon),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL WALLET BALANCE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EsportsGreen.copy(alpha = 0.2f),
                        border = BorderStroke(0.5.dp, EsportsGreen)
                    ) {
                        Text(
                            text = "100% SECURE ESCROW",
                            color = EsportsGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = MoneyEngine.formatRupees(walletState.totalBalancePaise),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    color = EsportsCyan
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Breakdown: Deposit Balance & Winning Withdrawable Balance
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Deposit Balance
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = EsportsSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Deposit Balance",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = MoneyEngine.formatRupees(walletState.depositBalancePaise),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "For Match Entries",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Winning Balance (Withdrawable)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = EsportsSurfaceVariant,
                        border = BorderStroke(1.dp, CardBorderGold),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Winning Balance",
                                style = MaterialTheme.typography.labelSmall,
                                color = EsportsGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = MoneyEngine.formatRupees(walletState.winningWithdrawablePaise),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = EsportsGold
                            )
                            Text(
                                text = "Withdrawable via UPI/Bank",
                                style = MaterialTheme.typography.bodySmall,
                                color = EsportsGold.copy(alpha = 0.7f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons: ADD MONEY & WITHDRAW
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { showAddMoneyDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("wallet_add_money_button")
                    ) {
                        Icon(Icons.Filled.AddCircle, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ADD MONEY", color = Color.Black, fontWeight = FontWeight.Black)
                    }

                    Button(
                        onClick = {
                            if (userProfile?.kycStatus != KycStatus.VERIFIED) {
                                onStartKyc()
                            } else {
                                showWithdrawDialog = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EsportsGold),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("wallet_withdraw_button")
                    ) {
                        Icon(Icons.Filled.AccountBalance, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WITHDRAW", color = Color.Black, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Transactions History Header & Filters
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = "TRANSACTION PASSBOOK",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedTxFilter == null,
                        onClick = { selectedTxFilter = null },
                        label = { Text("All") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EsportsCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
                items(TransactionType.values()) { type ->
                    FilterChip(
                        selected = selectedTxFilter == type,
                        onClick = { selectedTxFilter = type },
                        label = { Text(type.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EsportsCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        // Transactions List
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No transactions found in this category.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTransactions, key = { it.id }) { tx ->
                    TransactionItemRow(tx = tx)
                }
            }
        }
    }

    // Add Money Dialog
    if (showAddMoneyDialog) {
        AddMoneyDialog(
            onDismiss = { showAddMoneyDialog = false },
            onConfirm = { amountPaise, method ->
                showAddMoneyDialog = false
                onAddMoney(amountPaise, method)
            }
        )
    }

    // Withdraw Money Dialog
    if (showWithdrawDialog) {
        WithdrawDialog(
            maxWithdrawablePaise = walletState.winningWithdrawablePaise,
            userProfile = userProfile,
            onDismiss = { showWithdrawDialog = false },
            onConfirm = { amountPaise, method, dest ->
                showWithdrawDialog = false
                onWithdrawMoney(amountPaise, method, dest)
            }
        )
    }
}

@Composable
fun TransactionItemRow(tx: WalletTransactionRecord) {
    val dateString = remember(tx.timestamp) {
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        sdf.format(Date(tx.timestamp))
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = EsportsSurface,
        border = BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (tx.type.isCredit) EsportsGreen.copy(alpha = 0.15f)
                            else EsportsCrimson.copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (tx.type.isCredit) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward,
                        contentDescription = null,
                        tint = if (tx.type.isCredit) EsportsGreen else EsportsCrimson,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = tx.description,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$dateString • Ref: ${tx.referenceId}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (tx.type.isCredit) "+" else "-"}${MoneyEngine.formatRupees(tx.amountPaise)}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = if (tx.type.isCredit) EsportsGreen else EsportsCrimson
                )
                Text(
                    text = "Bal: ${MoneyEngine.formatRupees(tx.balanceAfterPaise)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun AddMoneyDialog(
    onDismiss: () -> Unit,
    onConfirm: (amountPaise: Long, method: PaymentMethod) -> Unit
) {
    val presets = listOf(100L, 200L, 500L, 1000L, 2000L, 5000L)
    var selectedAmountRupees by remember { mutableStateOf(500L) }
    var selectedMethod by remember { mutableStateOf(PaymentMethod.UPI_GPAY) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Add Funds to Real Wallet", color = EsportsCyan, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Select deposit amount or enter custom amount:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Presets Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.take(3).forEach { amount ->
                        FilterChip(
                            selected = selectedAmountRupees == amount,
                            onClick = { selectedAmountRupees = amount },
                            label = { Text("₹$amount", fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsCyan,
                                selectedLabelColor = Color.Black
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.drop(3).forEach { amount ->
                        FilterChip(
                            selected = selectedAmountRupees == amount,
                            onClick = { selectedAmountRupees = amount },
                            label = { Text("₹$amount", fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EsportsCyan,
                                selectedLabelColor = Color.Black
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Select Payment Gateway:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                PaymentMethod.values().forEach { method ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (selectedMethod == method) EsportsSurfaceElevated else EsportsSurface,
                        border = BorderStroke(
                            1.dp,
                            if (selectedMethod == method) EsportsCyan else CardBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedMethod = method }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMethod == method,
                                onClick = { selectedMethod = method },
                                colors = RadioButtonDefaults.colors(selectedColor = EsportsCyan)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = method.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = method.iconDescription,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(MoneyEngine.rupeesToPaise(selectedAmountRupees), selectedMethod)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EsportsCyan)
            ) {
                Text(
                    text = "PAY ₹$selectedAmountRupees INSTANTLY",
                    color = Color.Black,
                    fontWeight = FontWeight.Black
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextSecondary)
            }
        },
        containerColor = EsportsSurface,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun WithdrawDialog(
    maxWithdrawablePaise: Long,
    userProfile: UserProfile?,
    onDismiss: () -> Unit,
    onConfirm: (amountPaise: Long, method: WithdrawalMethod, destination: String) -> Unit
) {
    var amountInput by remember { mutableStateOf("500") }
    var selectedMethod by remember { mutableStateOf(WithdrawalMethod.UPI) }
    var destinationInput by remember { mutableStateOf("aditya.battle@okhdfcbank") }

    val amountRupees = amountInput.toLongOrNull() ?: 0L
    val amountPaise = MoneyEngine.rupeesToPaise(amountRupees)
    val isValid = amountPaise in 10000L..maxWithdrawablePaise && destinationInput.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Instant Bank / UPI Withdrawal", color = EsportsGold, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EsportsSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Withdrawable Balance:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text(
                            MoneyEngine.formatRupees(maxWithdrawablePaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EsportsGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Withdrawal Amount (₹)") },
                    leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = EsportsGold, modifier = Modifier.padding(start = 12.dp)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Method selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedMethod == WithdrawalMethod.UPI,
                        onClick = {
                            selectedMethod = WithdrawalMethod.UPI
                            destinationInput = "aditya.battle@okhdfcbank"
                        },
                        label = { Text("UPI Handle", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EsportsGold,
                            selectedLabelColor = Color.Black
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = selectedMethod == WithdrawalMethod.BANK_ACCOUNT,
                        onClick = {
                            selectedMethod = WithdrawalMethod.BANK_ACCOUNT
                            destinationInput = "HDFC0001234 - A/C 99881122"
                        },
                        label = { Text("Bank IMPS", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EsportsGold,
                            selectedLabelColor = Color.Black
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = destinationInput,
                    onValueChange = { destinationInput = it },
                    label = { Text(if (selectedMethod == WithdrawalMethod.UPI) "UPI VPA ID" else "Bank Account & IFSC") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "• 100% Instant IMPS transfer.\n• Minimum withdrawal is ₹100.\n• Real-money compliant and TDS audited as per government norms.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(amountPaise, selectedMethod, destinationInput) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = EsportsGold)
            ) {
                Text("WITHDRAW ₹$amountRupees", color = Color.Black, fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextSecondary)
            }
        },
        containerColor = EsportsSurface,
        shape = RoundedCornerShape(16.dp)
    )
}
