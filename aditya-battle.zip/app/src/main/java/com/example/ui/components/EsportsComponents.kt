package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.theme.*

@Composable
fun EsportsTopHeader(
    user: UserProfile?,
    walletState: WalletState,
    onWalletClick: () -> Unit,
    onCoinsClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    onToggleRoleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = EsportsSurface,
        border = BorderStroke(1.dp, CardBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Profile & Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClick = onProfileClick)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, EsportsCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.banner_aditya_founder_1787621660204),
                        contentDescription = "User Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = user?.username ?: "Player",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (user?.role == UserRole.ADMIN) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = EsportsCrimson.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(0.5.dp, EsportsCrimson)
                            ) {
                                Text(
                                    text = "ADMIN",
                                    color = EsportsCrimson,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "IGN: ${user?.inGameName ?: "Ready"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // Balances & Notification Icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Wallet Chip
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = EsportsSurfaceVariant,
                    border = BorderStroke(1.dp, CardBorderNeon),
                    modifier = Modifier
                        .testTag("wallet_balance_header_chip")
                        .clickable(onClick = onWalletClick)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AccountBalanceWallet,
                            contentDescription = "Wallet",
                            tint = EsportsCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = MoneyEngine.formatRupees(walletState.totalBalancePaise),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = EsportsCyan
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Filled.AddCircle,
                            contentDescription = "Add Funds",
                            tint = EsportsGreen,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Coins Chip
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = EsportsSurfaceVariant,
                    border = BorderStroke(1.dp, CardBorderGold),
                    modifier = Modifier.clickable(onClick = onCoinsClick)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MonetizationOn,
                            contentDescription = "Coins",
                            tint = EsportsGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${walletState.coinBalance}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = EsportsGold
                        )
                    }
                }

                // Bell Icon
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = TextPrimary
                    )
                }

                // Quick Admin Toggle
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (user?.role == UserRole.ADMIN) EsportsCrimson else EsportsSurfaceElevated,
                    modifier = Modifier
                        .clickable(onClick = onToggleRoleClick)
                        .padding(2.dp)
                ) {
                    Text(
                        text = if (user?.role == UserRole.ADMIN) "ADMIN" else "TEST ROLE",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TournamentCard(
    tournament: TournamentItem,
    onClick: () -> Unit,
    onJoinClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val calculation = MoneyEngine.calculateDistribution(tournament.entryFeePaise, tournament.maxSlots)
    val fillPercentage = if (tournament.maxSlots > 0) tournament.filledSlots.toFloat() / tournament.maxSlots.toFloat() else 0f

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        border = BorderStroke(
            1.dp,
            when {
                tournament.isJoined -> CardBorderCrimson
                tournament.status == TournamentStatus.LIVE -> CardBorderCrimson
                else -> CardBorder
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column {
            // Card Banner / Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                if (tournament.customBannerRes != null) {
                    Image(
                        painter = painterResource(id = tournament.customBannerRes),
                        contentDescription = tournament.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(EsportsSurfaceVariant, EsportsSurfaceElevated)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EmojiEvents,
                            contentDescription = null,
                            tint = EsportsCyan.copy(alpha = 0.4f),
                            modifier = Modifier.size(54.dp)
                        )
                    }
                }

                // Overlay gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                            )
                        )
                )

                // Status Badge & Category
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        border = BorderStroke(0.5.dp, EsportsCyan)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VideogameAsset,
                                contentDescription = null,
                                tint = EsportsCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = tournament.category.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = EsportsCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    StatusBadge(status = tournament.status, isJoined = tournament.isJoined)
                }

                // Map and Format details at bottom of banner
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DifficultyBadge(difficulty = tournament.difficulty)

                    if (tournament.isPocketTournament) {
                        PocketTournamentBadge(entryFeePaise = tournament.entryFeePaise)
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EsportsDarkBackground.copy(alpha = 0.8f)
                    ) {
                        Text(
                            text = "${tournament.matchFormat.label} • ${tournament.mapName.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Card Body
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tournament.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Key Financials Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EsportsSurfaceVariant, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Prize Pool
                    Column {
                        Text(
                            text = "PRIZE POOL (${if (tournament.isFree) "COINS" else "${calculation.prizePoolPercent}%"})",
                            style = MaterialTheme.typography.labelSmall,
                            color = EsportsGold
                        )
                        Text(
                            text = if (tournament.isFree) "500 Coins" else MoneyEngine.formatRupees(calculation.prizePoolPaise),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = EsportsGold
                        )
                    }

                    // Entry Fee
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "ENTRY FEE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = if (tournament.isFree) "FREE" else "${MoneyEngine.formatRupees(tournament.entryFeePaise)} / player",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (tournament.isFree) EsportsGreen else EsportsCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Slots Progress Bar
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Slots: ${tournament.filledSlots} / ${tournament.maxSlots}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "${tournament.remainingSlots} spots left",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (tournament.remainingSlots < 5) EsportsCrimson else EsportsCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { fillPercentage },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (fillPercentage >= 0.9f) EsportsCrimson else EsportsCyan,
                        trackColor = EsportsSurfaceVariant,
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // CTA Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.AccessTime,
                            contentDescription = null,
                            tint = TextTertiary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (tournament.status == TournamentStatus.LIVE) "Ongoing Now" else "Starts Soon",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary
                        )
                    }

                    when {
                        tournament.isJoined -> {
                            Button(
                                onClick = onClick,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EsportsGreen),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                modifier = Modifier.height(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "JOINED • VIEW ROOM",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                        tournament.isFull -> {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = EsportsSurfaceElevated,
                                modifier = Modifier.height(38.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                ) {
                                    Text(
                                        text = "FULL",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextTertiary
                                    )
                                }
                            }
                        }
                        tournament.status == TournamentStatus.COMPLETED -> {
                            OutlinedButton(
                                onClick = onClick,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(38.dp)
                            ) {
                                Text(text = "VIEW RESULTS", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        else -> {
                            Button(
                                onClick = onJoinClick,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (tournament.isFree) EsportsGreen else EsportsCyan
                                ),
                                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(38.dp)
                                    .testTag("tournament_join_button_${tournament.id}")
                            ) {
                                Text(
                                    text = if (tournament.isFree) "JOIN FREE" else "JOIN NOW",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: TournamentStatus, isJoined: Boolean) {
    val (bgColor, textColor, text) = when {
        isJoined -> Triple(EsportsGreen.copy(alpha = 0.2f), EsportsGreen, "REGISTERED")
        status == TournamentStatus.LIVE -> Triple(EsportsCrimson.copy(alpha = 0.2f), EsportsCrimson, "LIVE MATCH")
        status == TournamentStatus.OPEN -> Triple(EsportsCyan.copy(alpha = 0.2f), EsportsCyan, "OPEN")
        status == TournamentStatus.FULL -> Triple(EsportsSurfaceElevated, TextTertiary, "FULL")
        status == TournamentStatus.COMPLETED -> Triple(EsportsSurfaceElevated, TextSecondary, "COMPLETED")
        status == TournamentStatus.CANCELLED -> Triple(EsportsCrimson.copy(alpha = 0.2f), EsportsCrimson, "CANCELLED")
        else -> Triple(EsportsSurfaceElevated, TextSecondary, status.label)
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.6f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            if (status == TournamentStatus.LIVE) {
                // Pulsing dot for live status
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val alpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulseAlpha"
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(EsportsCrimson.copy(alpha = alpha))
                )
                Spacer(modifier = Modifier.width(5.dp))
            }

            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
fun DifficultyBadge(
    difficulty: TournamentDifficulty,
    modifier: Modifier = Modifier
) {
    val (color, bg) = when (difficulty) {
        TournamentDifficulty.EASY -> Pair(Color(0xFF00E676), Color(0xFF00E676).copy(alpha = 0.15f))
        TournamentDifficulty.NORMAL -> Pair(EsportsCyan, EsportsCyan.copy(alpha = 0.15f))
        TournamentDifficulty.MEDIUM -> Pair(EsportsGold, EsportsGold.copy(alpha = 0.15f))
        TournamentDifficulty.HARD -> Pair(EsportsCrimson, EsportsCrimson.copy(alpha = 0.15f))
        TournamentDifficulty.MEGA -> Pair(EsportsPurple, EsportsPurple.copy(alpha = 0.2f))
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bg,
        border = BorderStroke(1.dp, color.copy(alpha = 0.7f)),
        modifier = modifier
    ) {
        Text(
            text = difficulty.shortTag,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun PocketTournamentBadge(
    entryFeePaise: Long,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFFFFD700).copy(alpha = 0.18f),
        border = BorderStroke(1.dp, Color(0xFFFFD700)),
        modifier = modifier
    ) {
        Text(
            text = "⚡ POCKET ${MoneyEngine.formatRupees(entryFeePaise)}",
            color = Color(0xFFFFD700),
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun RoomInfoCard(
    roomId: String,
    roomPassword: String,
    roomReleaseTime: String,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EsportsSurfaceVariant),
        border = BorderStroke(1.dp, CardBorderCrimson),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Room Lock",
                        tint = EsportsCrimson,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ROOM CREDENTIALS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EsportsCrimson
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EsportsCrimson.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "CONFIDENTIAL",
                        color = EsportsCrimson,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (roomId.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Room ID Card
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = EsportsSurfaceElevated,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "ROOM ID", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = roomId,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = EsportsCyan
                                )
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(roomId))
                                        Toast.makeText(context, "Room ID copied!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy Room ID",
                                        tint = EsportsCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Room Password Card
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = EsportsSurfaceElevated,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "PASSWORD", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = roomPassword,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = EsportsGold
                                )
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(roomPassword))
                                        Toast.makeText(context, "Password copied!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy Room Password",
                                        tint = EsportsGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = EsportsSurfaceElevated,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = null,
                            tint = EsportsCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Room ID and Password will unlock automatically $roomReleaseTime.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FinancialPreviewCard(
    calculation: MoneyEngine.FinancialCalculation,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        border = BorderStroke(1.dp, CardBorderGold),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "FINANCIAL PREVIEW & MATHEMATICAL AUDIT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsGold
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EsportsGreen.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "100% BALANCED",
                        color = EsportsGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gross Pool Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(EsportsSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "GROSS ENTRY POOL", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        text = "${calculation.participants} Players × ${MoneyEngine.formatRupees(calculation.entryFeePaise)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary
                    )
                }
                Text(
                    text = MoneyEngine.formatRupees(calculation.grossPoolPaise),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Distribution Splits
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Prize Pool (80% / 85%)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EsportsSurfaceVariant,
                    border = BorderStroke(1.dp, CardBorderGold),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "PRIZE POOL (${calculation.prizePoolPercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = EsportsGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = MoneyEngine.formatRupees(calculation.prizePoolPaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EsportsGold
                        )
                    }
                }

                // Platform Share (15% / 20%)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EsportsSurfaceVariant,
                    border = BorderStroke(1.dp, CardBorderNeon),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "PLATFORM SHARE (${calculation.platformSharePercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = EsportsCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = MoneyEngine.formatRupees(calculation.platformSharePaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EsportsCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Rank Prizes Table
            Text(
                text = "Rank Payout Distribution",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))

            calculation.rankPrizesPaise.forEach { rankPrize ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = when (rankPrize.rank) {
                                1 -> EsportsGold
                                2 -> Color(0xFFC0C0C0)
                                3 -> Color(0xFFCD7F32)
                                else -> EsportsSurfaceElevated
                            },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${rankPrize.rank}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = rankPrize.rankLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = MoneyEngine.formatRupees(rankPrize.prizePaise),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (rankPrize.rank == 1) EsportsGold else TextPrimary
                    )
                }
                HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
            }
        }
    }
}
