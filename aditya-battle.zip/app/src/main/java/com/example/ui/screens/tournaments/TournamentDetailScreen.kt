package com.example.ui.screens.tournaments

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.math.MoneyEngine
import com.example.core.model.*
import com.example.ui.components.DifficultyBadge
import com.example.ui.components.FinancialPreviewCard
import com.example.ui.components.PocketTournamentBadge
import com.example.ui.components.RoomInfoCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class TournamentDetailTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    OVERVIEW("Overview", Icons.Filled.Info),
    PRIZES("Prizes & Ranks", Icons.Filled.EmojiEvents),
    PARTICIPANTS("Participants", Icons.Filled.PeopleAlt),
    RULES("Rules", Icons.Filled.Gavel)
}

@Composable
fun TournamentDetailScreen(
    tournament: TournamentItem,
    walletState: WalletState,
    onBackClick: () -> Unit,
    onJoinClick: () -> Unit,
    onAddMoneyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val calculation = remember(tournament.entryFeePaise, tournament.maxSlots) {
        MoneyEngine.calculateDistribution(tournament.entryFeePaise, tournament.maxSlots)
    }

    var selectedTab by remember { mutableStateOf(TournamentDetailTab.OVERVIEW) }
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Format Scheduled Time
    val timeFormat = remember { SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()) }
    val formattedTime = remember(tournament.scheduledTimeEpoch) {
        timeFormat.format(Date(tournament.scheduledTimeEpoch))
    }

    val hasSufficientBalance = walletState.totalBalancePaise >= tournament.entryFeePaise
    val balanceDeficit = (tournament.entryFeePaise - walletState.totalBalancePaise).coerceAtLeast(0L)

    // Generate dynamic roster of participants for display
    val participantsList = remember(tournament.id, tournament.filledSlots, tournament.isJoined) {
        generateParticipantsRoster(tournament)
    }

    Scaffold(
        topBar = {
            Surface(
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = "Tournament Details",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${tournament.category.displayName} • ${tournament.matchFormat.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = EsportsCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Share button
                    IconButton(
                        onClick = {
                            clipboardManager.setText(
                                AnnotatedString(
                                    "🔥 Join ${tournament.title} on Aditya Battle Esports! Entry: ${
                                        if (tournament.isFree) "FREE" else MoneyEngine.formatRupees(tournament.entryFeePaise)
                                    }, Prize Pool: ${MoneyEngine.formatRupees(calculation.prizePoolPaise)}. Download & Play now!"
                                )
                            )
                            Toast.makeText(context, "Tournament link copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = EsportsCyan)
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "ENTRY FEE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (tournament.isFree) "FREE" else MoneyEngine.formatRupees(tournament.entryFeePaise),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = if (tournament.isFree) EsportsGreen else EsportsCyan
                            )
                            if (!tournament.isFree) {
                                Text(
                                    text = " / slot",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        if (!tournament.isFree && !tournament.isJoined) {
                            Text(
                                text = "Wallet: ${MoneyEngine.formatRupees(walletState.totalBalancePaise)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (hasSufficientBalance) EsportsGreen else EsportsCrimson
                            )
                        }
                    }

                    when {
                        tournament.isJoined -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = EsportsGreen.copy(alpha = 0.15f),
                                border = BorderStroke(1.5.dp, EsportsGreen)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = EsportsGreen,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "REGISTERED",
                                        color = EsportsGreen,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                        tournament.isFull -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = EsportsSurfaceElevated,
                                border = BorderStroke(1.dp, CardBorder)
                            ) {
                                Text(
                                    text = "SLOTS FULL",
                                    color = TextTertiary,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)
                                )
                            }
                        }
                        !tournament.isFree && !hasSufficientBalance -> {
                            Button(
                                onClick = onAddMoneyClick,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EsportsGold),
                                modifier = Modifier
                                    .height(46.dp)
                                    .testTag("detail_add_money_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AddCircle,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ADD ${MoneyEngine.formatRupees(balanceDeficit)} TO JOIN",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp
                                )
                            }
                        }
                        else -> {
                            Button(
                                onClick = onJoinClick,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (tournament.isFree) EsportsGreen else EsportsCyan
                                ),
                                modifier = Modifier
                                    .height(46.dp)
                                    .testTag("detail_join_button")
                            ) {
                                Icon(
                                    imageVector = if (tournament.isFree) Icons.Filled.Stars else Icons.Filled.Bolt,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (tournament.isFree) "REGISTER FREE" else "JOIN TOURNAMENT",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(EsportsDarkBackground)
                .padding(innerPadding)
        ) {
            // Scrollable Content
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Hero Banner Header
                item {
                    TournamentDetailHeader(
                        tournament = tournament,
                        formattedTime = formattedTime
                    )
                }

                // Dynamic Tab Navigation Row
                item {
                    ScrollableTabRow(
                        selectedTabIndex = selectedTab.ordinal,
                        containerColor = EsportsSurface,
                        contentColor = EsportsCyan,
                        edgePadding = 16.dp,
                        indicator = { tabPositions ->
                            if (selectedTab.ordinal < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                                    color = EsportsCyan,
                                    height = 3.dp
                                )
                            }
                        },
                        divider = {
                            HorizontalDivider(color = CardBorder, thickness = 1.dp)
                        }
                    ) {
                        TournamentDetailTab.values().forEach { tab ->
                            val isSelected = selectedTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { selectedTab = tab },
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = tab.icon,
                                            contentDescription = null,
                                            tint = if (isSelected) EsportsCyan else TextTertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = tab.title,
                                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                            color = if (isSelected) EsportsCyan else TextSecondary,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            )
                        }
                    }
                }

                // Tab Content
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        when (selectedTab) {
                            TournamentDetailTab.OVERVIEW -> {
                                OverviewTabContent(
                                    tournament = tournament,
                                    calculation = calculation
                                )
                            }
                            TournamentDetailTab.PRIZES -> {
                                PrizesTabContent(
                                    tournament = tournament,
                                    calculation = calculation
                                )
                            }
                            TournamentDetailTab.PARTICIPANTS -> {
                                ParticipantsTabContent(
                                    tournament = tournament,
                                    participants = participantsList
                                )
                            }
                            TournamentDetailTab.RULES -> {
                                RulesTabContent(tournament = tournament)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TournamentDetailHeader(
    tournament: TournamentItem,
    formattedTime: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        if (tournament.customBannerRes != null) {
            Image(
                painter = painterResource(id = tournament.customBannerRes),
                contentDescription = tournament.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(EsportsSurfaceVariant, EsportsSurfaceElevated)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.EmojiEvents,
                    contentDescription = null,
                    tint = EsportsCyan.copy(alpha = 0.35f),
                    modifier = Modifier.size(72.dp)
                )
            }
        }

        // Gradient protection for text legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.Black.copy(alpha = 0.75f),
                            EsportsDarkBackground
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Badges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EsportsCyan
                    ) {
                        Text(
                            text = tournament.category.displayName,
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    DifficultyBadge(difficulty = tournament.difficulty)

                    if (tournament.isPocketTournament) {
                        PocketTournamentBadge(entryFeePaise = tournament.entryFeePaise)
                    }
                }

                StatusBadge(status = tournament.status, isJoined = tournament.isJoined)
            }

            // Bottom Title & Schedule
            Column {
                Text(
                    text = tournament.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Schedule,
                            contentDescription = null,
                            tint = EsportsGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.bodySmall,
                            color = EsportsGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Map,
                            contentDescription = null,
                            tint = EsportsCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tournament.mapName.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewTabContent(
    tournament: TournamentItem,
    calculation: MoneyEngine.FinancialCalculation
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Match Specifications Grid
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "MATCH SPECIFICATIONS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsCyan
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    SpecItem(
                        icon = Icons.Filled.Group,
                        label = "Format",
                        value = tournament.matchFormat.label,
                        accentColor = EsportsCyan
                    )
                    SpecItem(
                        icon = Icons.Filled.Map,
                        label = "Map",
                        value = tournament.mapName.label,
                        accentColor = EsportsCrimson
                    )
                    SpecItem(
                        icon = Icons.Filled.PeopleAlt,
                        label = "Slots",
                        value = "${tournament.filledSlots}/${tournament.maxSlots}",
                        accentColor = EsportsGold
                    )
                    SpecItem(
                        icon = Icons.Filled.CrisisAlert,
                        label = "Per Kill",
                        value = if (tournament.isFree) "50 Coins" else MoneyEngine.formatRupees(tournament.killPointRewardPaise),
                        accentColor = EsportsGreen
                    )
                }
            }
        }

        // Slots Filling Progress Bar
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                val fillPercentage = if (tournament.maxSlots > 0) tournament.filledSlots.toFloat() / tournament.maxSlots.toFloat() else 0f
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.HowToReg,
                            contentDescription = null,
                            tint = EsportsCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Registration Progress",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = "${tournament.remainingSlots} spots left",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Black,
                        color = if (tournament.remainingSlots < 5) EsportsCrimson else EsportsCyan
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { fillPercentage },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (fillPercentage >= 0.9f) EsportsCrimson else EsportsCyan,
                    trackColor = EsportsSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${tournament.filledSlots} players joined",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Max: ${tournament.maxSlots} players",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Confidential Room ID / Password Card
        RoomInfoCard(
            roomId = if (tournament.isJoined) tournament.roomId else "",
            roomPassword = if (tournament.isJoined) tournament.roomPassword else "",
            roomReleaseTime = tournament.roomReleaseTime
        )

        // Mathematical Financial Preview Card
        FinancialPreviewCard(calculation = calculation)

        // Description Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ABOUT THIS TOURNAMENT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsCyan
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = tournament.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun PrizesTabContent(
    tournament: TournamentItem,
    calculation: MoneyEngine.FinancialCalculation
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Big Total Prize Pool Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.5.dp, CardBorderGold)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                EsportsGold.copy(alpha = 0.15f),
                                EsportsDarkBackground.copy(alpha = 0.6f)
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TOTAL GUARANTEED PRIZE POOL",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = EsportsGold
                            )
                            Text(
                                text = if (tournament.isFree) "500 Coins" else MoneyEngine.formatRupees(calculation.prizePoolPaise),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Black,
                                color = EsportsGold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EsportsGold,
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Text(
                                text = "${calculation.prizePoolPercent}% POOL",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "⚡ Instant UPI settlement directly to your winning wallet immediately after match result confirmation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Rank by Rank Breakdown Table
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "RANK-WISE PRIZE DISTRIBUTION",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsCyan
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (calculation.rankPrizesPaise.isEmpty()) {
                    Text(
                        text = "Free practice tournament: Winner receives 500 bonus coins.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                } else {
                    calculation.rankPrizesPaise.forEach { prize ->
                        val medalColor = when (prize.rank) {
                            1 -> EsportsGold
                            2 -> Color(0xFFC0C0C0) // Silver
                            3 -> Color(0xFFCD7F32) // Bronze
                            else -> EsportsCyan
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (prize.rank == 1) EsportsSurfaceElevated else EsportsSurfaceVariant,
                            border = if (prize.rank == 1) BorderStroke(1.dp, CardBorderGold) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(medalColor.copy(alpha = 0.2f))
                                            .border(1.dp, medalColor, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "#${prize.rank}",
                                            color = medalColor,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = prize.rankLabel,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = "${String.format(Locale.US, "%.1f", prize.percentage)}% of prize pool",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextTertiary,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Text(
                                    text = MoneyEngine.formatRupees(prize.prizePaise),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = if (prize.rank == 1) EsportsGold else TextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Per-Kill Bounty Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(EsportsCrimson.copy(alpha = 0.2f))
                        .border(1.dp, EsportsCrimson, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CrisisAlert,
                        contentDescription = null,
                        tint = EsportsCrimson,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PER-KILL REWARD BOUNTY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = EsportsCrimson
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (tournament.isFree) "50 Coins for every confirmed kill" else "${MoneyEngine.formatRupees(tournament.killPointRewardPaise)} credited per confirmed kill in addition to placement ranks.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ParticipantsTabContent(
    tournament: TournamentItem,
    participants: List<ParticipantRecord>
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Summary Header Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CONFIRMED PARTICIPANTS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = EsportsCyan
                    )
                    Text(
                        text = "${tournament.filledSlots} of ${tournament.maxSlots} slots occupied",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (tournament.isFull) EsportsCrimson.copy(alpha = 0.2f) else EsportsCyan.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, if (tournament.isFull) EsportsCrimson else EsportsCyan)
                ) {
                    Text(
                        text = if (tournament.isFull) "ALL SLOTS FILLED" else "${tournament.remainingSlots} OPEN SLOTS",
                        color = if (tournament.isFull) EsportsCrimson else EsportsCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Roster List
        participants.forEach { participant ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                border = BorderStroke(0.5.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = EsportsSurfaceElevated,
                            border = BorderStroke(1.dp, EsportsCyan.copy(alpha = 0.5f)),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "#${participant.slotNumber}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp,
                                    color = EsportsCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = participant.inGameName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "UID: ${participant.inGameId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EsportsGreen.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "CONFIRMED",
                            color = EsportsGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (tournament.remainingSlots > 0) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EsportsDarkBackground,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddCircleOutline,
                        contentDescription = null,
                        tint = EsportsCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "+ ${tournament.remainingSlots} open slots available for registration",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun RulesTabContent(tournament: TournamentItem) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Fair Play Guarantee Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorderCrimson)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = null,
                        tint = EsportsCrimson,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "100% FAIR PLAY & ANTI-CHEAT MANDATE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        color = EsportsCrimson
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "• Emulators, iPad view mods, scripts, and third-party tools are strictly prohibited.\n• Room matches are recorded and audited by the Aditya Battle admin team.\n• Any team or player found guilty of cross-teaming or teaming will be permanently banned and entry forfeited.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    lineHeight = 18.sp
                )
            }
        }

        // Official Tournament Rules List
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "OFFICIAL MATCH RULES",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsCyan
                )

                Spacer(modifier = Modifier.height(10.dp))

                tournament.rules.forEachIndexed { index, rule ->
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "${index + 1}.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Black,
                            color = EsportsCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = rule,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        }

        // Room ID & Entry Instructions
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "HOW TO JOIN CUSTOM ROOM IN-GAME",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsGold
                )

                Spacer(modifier = Modifier.height(8.dp))

                val instructions = listOf(
                    "Copy Room ID & Password from this screen (${tournament.roomReleaseTime}).",
                    "Open Free Fire -> Select Custom Mode -> Search Room ID.",
                    "Enter the password and take your assigned slot number.",
                    "Do not invite non-registered friends. Match starts strictly on time."
                )

                instructions.forEachIndexed { index, inst ->
                    Row(
                        modifier = Modifier.padding(vertical = 3.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "Step ${index + 1}: ",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = EsportsGold
                        )
                        Text(
                            text = inst,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SpecItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accentColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextTertiary,
            fontSize = 10.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

private fun generateParticipantsRoster(tournament: TournamentItem): List<ParticipantRecord> {
    val dummyNames = listOf(
        "ShadowHunter", "Viper_99", "AlphaWolf", "GodfatherFF", "SniperKing",
        "FalconStrike", "GhostRider", "ThunderBolt", "HydraPro", "ApexLegend",
        "BulletProof", "NightHawk", "Immortal7", "DragonSlayer", "BlazeWarrior",
        "PsychoKiller", "TitanForce", "RapidFire", "RogueOne", "Maverick_X"
    )

    val count = tournament.filledSlots.coerceAtLeast(0)
    return (1..count).map { slot ->
        val nameIndex = (slot - 1) % dummyNames.size
        val name = if (tournament.isJoined && slot == 1) "You (ShadowHunter)" else dummyNames[nameIndex]
        val uid = 84920400L + slot * 17L
        ParticipantRecord(
            id = "part_${tournament.id}_$slot",
            tournamentId = tournament.id,
            userId = "user_$slot",
            username = name,
            inGameName = name,
            inGameId = "$uid",
            entryFeePaise = tournament.entryFeePaise,
            transactionId = "TXN_${tournament.id}_$slot",
            slotNumber = slot,
            joinedAt = System.currentTimeMillis() - (slot * 300000L)
        )
    }
}
