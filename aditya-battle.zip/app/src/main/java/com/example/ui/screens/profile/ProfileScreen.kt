package com.example.ui.screens.profile

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.core.model.*
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    onStartKyc: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onToggleRole: () -> Unit,
    onLogout: () -> Unit,
    onOpenCompliance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showKycDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EsportsDarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 100.dp)
    ) {
        // Profile Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .border(2.dp, EsportsCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.banner_aditya_founder_1787621660204),
                        contentDescription = "Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = userProfile?.username ?: "Player",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )

                Text(
                    text = userProfile?.email ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                // In-Game Credentials Chip
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EsportsSurfaceVariant,
                    border = BorderStroke(1.dp, CardBorderNeon)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VideogameAsset,
                            contentDescription = null,
                            tint = EsportsCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "IGN: ${userProfile?.inGameName} • ID: ${userProfile?.inGameId}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = EsportsCyan
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Esports Career Stats Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CAREER BATTLE STATS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EsportsGold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatBox(label = "Matches", value = "${userProfile?.totalTournaments ?: 0}", color = EsportsCyan)
                    StatBox(label = "Wins (1st)", value = "${userProfile?.totalWins ?: 0}", color = EsportsGold)
                    StatBox(label = "Kills", value = "${userProfile?.totalKills ?: 0}", color = EsportsCrimson)
                    val winRate = if ((userProfile?.totalTournaments ?: 0) > 0) {
                        ((userProfile?.totalWins ?: 0).toFloat() / (userProfile?.totalTournaments ?: 1) * 100).toInt()
                    } else 0
                    StatBox(label = "Win Rate", value = "$winRate%", color = EsportsGreen)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // KYC Status Banner
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = EsportsSurface,
            border = BorderStroke(
                1.dp,
                if (userProfile?.kycStatus == KycStatus.VERIFIED) CardBorderNeon else CardBorderCrimson
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onStartKyc() }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (userProfile?.kycStatus == KycStatus.VERIFIED) Icons.Filled.VerifiedUser else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (userProfile?.kycStatus == KycStatus.VERIFIED) EsportsGreen else EsportsGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (userProfile?.kycStatus == KycStatus.VERIFIED) "KYC Verified" else "KYC Pending",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (userProfile?.kycStatus == KycStatus.VERIFIED) "Unlimited instant withdrawals active" else "Verify PAN & bank details to withdraw",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Settings / Actions List
        Text(
            text = "ACCOUNT & LEGAL COMPLIANCE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Admin Panel Entry (If Admin)
        if (userProfile?.role == UserRole.ADMIN) {
            ProfileMenuRow(
                icon = Icons.Filled.AdminPanelSettings,
                iconTint = EsportsCrimson,
                title = "Admin Control Dashboard",
                subtitle = "Tournaments, Room ID dispatch & Result Finalizer",
                onClick = onOpenAdminPanel
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        ProfileMenuRow(
            icon = Icons.Filled.SwapHoriz,
            iconTint = EsportsCyan,
            title = "Switch Role (${userProfile?.role?.name})",
            subtitle = "Toggle between USER and ADMIN for live demo testing",
            onClick = onToggleRole
        )

        Spacer(modifier = Modifier.height(8.dp))

        ProfileMenuRow(
            icon = Icons.Filled.Gavel,
            iconTint = EsportsGold,
            title = "Fair Play & Skill Gaming Policy",
            subtitle = "18+ restriction, anti-cheat & state legality rules",
            onClick = onOpenCompliance
        )

        Spacer(modifier = Modifier.height(8.dp))

        ProfileMenuRow(
            icon = Icons.Filled.SupportAgent,
            iconTint = EsportsCyan,
            title = "Customer Support & Dispute Desk",
            subtitle = "Instant resolution for matches and payment queries",
            onClick = { Toast.makeText(context, "Support ticket desk opened: 24x7 Active", Toast.LENGTH_SHORT).show() }
        )

        Spacer(modifier = Modifier.height(8.dp))

        ProfileMenuRow(
            icon = Icons.Filled.Logout,
            iconTint = EsportsCrimson,
            title = "Log Out",
            subtitle = "Safely sign out from current device",
            onClick = onLogout
        )
    }
}

@Composable
private fun StatBox(label: String, value: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = EsportsSurfaceVariant,
        modifier = Modifier.width(72.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = EsportsSurface,
        border = BorderStroke(1.dp, CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}
