package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.*
import com.example.ui.components.EsportsTopHeader
import com.example.ui.dialogs.ComplianceDialog
import com.example.ui.dialogs.JoinTournamentBottomSheet
import com.example.ui.dialogs.KycVerificationDialog
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.mymatches.MyMatchesScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.referral.ReferralScreen
import com.example.ui.screens.tasks.TasksAndRewardsScreen
import com.example.ui.screens.tournaments.TournamentDetailScreen
import com.example.ui.screens.tournaments.TournamentsScreen
import com.example.ui.screens.wallet.AddMoneyDialog
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.UiMessage

enum class ScreenDestination(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    TOURNAMENTS("Tournaments", Icons.Filled.EmojiEvents),
    MY_MATCHES("My Matches", Icons.Filled.SportsEsports),
    WALLET("Wallet", Icons.Filled.AccountBalanceWallet),
    PROFILE("Profile", Icons.Filled.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdityaBattleNav(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val walletState by viewModel.walletState.collectAsStateWithLifecycle()
    val tournaments by viewModel.tournaments.collectAsStateWithLifecycle()
    val filteredTournaments by viewModel.filteredTournaments.collectAsStateWithLifecycle()
    val myTournaments by viewModel.myTournaments.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val dailyTasks by viewModel.dailyTasks.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val matchResults by viewModel.matchResults.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val gameModes by viewModel.gameModes.collectAsStateWithLifecycle()
    val gameMaps by viewModel.gameMaps.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(ScreenDestination.HOME) }
    var selectedTournamentForDetail by remember { mutableStateOf<TournamentItem?>(null) }
    var tournamentToJoin by remember { mutableStateOf<TournamentItem?>(null) }
    var showAdminPanel by remember { mutableStateOf(false) }
    var showTasksScreen by remember { mutableStateOf(false) }
    var showReferralScreen by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var showKycDialog by remember { mutableStateOf(false) }
    var showComplianceDialog by remember { mutableStateOf(false) }
    var showDirectAddMoneyDialog by remember { mutableStateOf(false) }

    // Collect UI toast events
    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { msg ->
            when (msg) {
                is UiMessage.Success -> Toast.makeText(context, msg.message, Toast.LENGTH_SHORT).show()
                is UiMessage.Error -> Toast.makeText(context, msg.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    // If user is null, show Auth screen
    if (currentUser == null) {
        AuthScreen(
            onLoginSuccess = { email, pass -> viewModel.login(email, pass) },
            onRegisterSuccess = { name, email, phone, pass, ref ->
                viewModel.register(name, email, phone, pass, ref)
            },
            onSkipForDemo = {
                viewModel.login("aditya.esports@battle.in", "demo")
            }
        )
        return
    }

    // If viewing Admin Panel
    if (showAdminPanel) {
        AdminDashboardScreen(
            tournaments = tournaments,
            auditLogs = auditLogs,
            gameModes = gameModes,
            gameMaps = gameMaps,
            onBackClick = { showAdminPanel = false },
            onCreateTournament = { title, cat, fee, slots, format, map, hours, desc, rules, diff ->
                viewModel.adminCreateTournament(title, cat, fee, slots, format, map, hours, desc, rules, diff)
            },
            onCreateTournamentUniversal = { tournament ->
                viewModel.adminCreateTournamentUniversal(tournament)
            },
            onGenerateTournament = { mode, map, format, fee, slots, hours, fType, diff ->
                viewModel.adminGenerateTournament(mode, map, format, fee, slots, hours, fType, diff)
            },
            onAddMap = { name, cat, roomType, formats, minP, maxP, desc, enabled ->
                viewModel.adminAddMap(name, cat, roomType, formats, minP, maxP, desc, enabled)
            },
            onUpdateMap = { map -> viewModel.adminUpdateMap(map) },
            onToggleMap = { id, enabled -> viewModel.adminToggleMap(id, enabled) },
            onDeleteMap = { id -> viewModel.adminDeleteMap(id) },
            onToggleGameMode = { id, enabled -> viewModel.adminToggleGameMode(id, enabled) },
            onUpdateRoom = { id, room, pass -> viewModel.adminUpdateRoom(id, room, pass) },
            onFinalizeResults = { id, results -> viewModel.adminFinalizeResults(id, results) },
            onCancelTournament = { id, reason -> viewModel.adminCancelTournament(id, reason) }
        )
        return
    }

    // If viewing Tournament Detail Screen
    if (selectedTournamentForDetail != null) {
        val detailTour = tournaments.find { it.id == selectedTournamentForDetail?.id } ?: selectedTournamentForDetail!!
        TournamentDetailScreen(
            tournament = detailTour,
            walletState = walletState,
            onBackClick = { selectedTournamentForDetail = null },
            onJoinClick = {
                tournamentToJoin = detailTour
            },
            onAddMoneyClick = {
                showDirectAddMoneyDialog = true
            }
        )

        // Modal Sheet for Join
        tournamentToJoin?.let { tour ->
            JoinTournamentBottomSheet(
                tournament = tour,
                walletState = walletState,
                currentUser = currentUser,
                onDismiss = { tournamentToJoin = null },
                onConfirmJoin = { ign, igid ->
                    viewModel.joinTournament(tour.id, ign, igid)
                    tournamentToJoin = null
                },
                onAddMoneyRequired = {
                    tournamentToJoin = null
                    showDirectAddMoneyDialog = true
                }
            )
        }
        return
    }

    // Main Scaffold with Header & Bottom Navigation
    Scaffold(
        topBar = {
            EsportsTopHeader(
                user = currentUser,
                walletState = walletState,
                onWalletClick = { currentScreen = ScreenDestination.WALLET },
                onCoinsClick = { showTasksScreen = true },
                onNotificationClick = { showNotificationsDialog = true },
                onProfileClick = { currentScreen = ScreenDestination.PROFILE },
                onToggleRoleClick = { viewModel.toggleRole() }
            )
        },
        bottomBar = {
            Surface(
                color = EsportsSurface,
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.navigationBarsPadding()
            ) {
                NavigationBar(
                    containerColor = EsportsSurface,
                    contentColor = EsportsCyan,
                    modifier = Modifier.height(64.dp)
                ) {
                    ScreenDestination.values().forEach { destination ->
                        val isSelected = currentScreen == destination && !showTasksScreen && !showReferralScreen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                showTasksScreen = false
                                showReferralScreen = false
                                currentScreen = destination
                            },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = destination.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = EsportsCyan,
                                selectedTextColor = EsportsCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = EsportsSurfaceElevated
                            ),
                            modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                showTasksScreen -> {
                    TasksAndRewardsScreen(
                        walletState = walletState,
                        dailyTasks = dailyTasks,
                        onClaimDailyReward = { viewModel.claimDailyReward() },
                        onClaimTask = { viewModel.claimTaskReward(it) },
                        onReferralClick = {
                            showTasksScreen = false
                            showReferralScreen = true
                        }
                    )
                }
                showReferralScreen -> {
                    ReferralScreen(userProfile = currentUser)
                }
                currentScreen == ScreenDestination.HOME -> {
                    HomeScreen(
                        banners = viewModel.banners,
                        tournaments = tournaments,
                        myTournaments = myTournaments,
                        walletState = walletState,
                        selectedCategory = selectedCategory,
                        onCategorySelect = { viewModel.setCategoryFilter(it) },
                        onTournamentClick = { selectedTournamentForDetail = it },
                        onJoinTournamentClick = { tournamentToJoin = it },
                        onViewAllTournaments = { currentScreen = ScreenDestination.TOURNAMENTS },
                        onClaimDailyReward = { viewModel.claimDailyReward() },
                        onTasksClick = { showTasksScreen = true },
                        onReferralClick = { showReferralScreen = true },
                        onWalletClick = { currentScreen = ScreenDestination.WALLET }
                    )
                }
                currentScreen == ScreenDestination.TOURNAMENTS -> {
                    TournamentsScreen(
                        tournaments = filteredTournaments,
                        selectedCategory = selectedCategory,
                        searchQuery = searchQuery,
                        selectedStatus = selectedStatus,
                        onCategorySelect = { viewModel.setCategoryFilter(it) },
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onStatusSelect = { viewModel.setStatusFilter(it) },
                        onTournamentClick = { selectedTournamentForDetail = it },
                        onJoinTournamentClick = { tournamentToJoin = it }
                    )
                }
                currentScreen == ScreenDestination.MY_MATCHES -> {
                    MyMatchesScreen(
                        tournaments = tournaments,
                        matchResults = matchResults,
                        onTournamentClick = { selectedTournamentForDetail = it },
                        onExploreTournaments = { currentScreen = ScreenDestination.TOURNAMENTS }
                    )
                }
                currentScreen == ScreenDestination.WALLET -> {
                    WalletScreen(
                        walletState = walletState,
                        transactions = transactions,
                        userProfile = currentUser,
                        onAddMoney = { amount, method -> viewModel.addMoney(amount, method) },
                        onWithdrawMoney = { amount, method, dest -> viewModel.withdrawMoney(amount, method, dest) },
                        onStartKyc = { showKycDialog = true }
                    )
                }
                currentScreen == ScreenDestination.PROFILE -> {
                    ProfileScreen(
                        userProfile = currentUser,
                        onStartKyc = { showKycDialog = true },
                        onOpenAdminPanel = { showAdminPanel = true },
                        onToggleRole = { viewModel.toggleRole() },
                        onLogout = { viewModel.login("", "") },
                        onOpenCompliance = { showComplianceDialog = true }
                    )
                }
            }

            // Global Join Tournament Modal
            tournamentToJoin?.let { tour ->
                JoinTournamentBottomSheet(
                    tournament = tour,
                    walletState = walletState,
                    currentUser = currentUser,
                    onDismiss = { tournamentToJoin = null },
                    onConfirmJoin = { ign, igid ->
                        viewModel.joinTournament(tour.id, ign, igid)
                        tournamentToJoin = null
                    },
                    onAddMoneyRequired = {
                        tournamentToJoin = null
                        showDirectAddMoneyDialog = true
                    }
                )
            }

            // Direct Add Money Dialog
            if (showDirectAddMoneyDialog) {
                AddMoneyDialog(
                    onDismiss = { showDirectAddMoneyDialog = false },
                    onConfirm = { amountPaise, method ->
                        showDirectAddMoneyDialog = false
                        viewModel.addMoney(amountPaise, method)
                    }
                )
            }

            // KYC Dialog
            if (showKycDialog) {
                KycVerificationDialog(
                    onDismiss = { showKycDialog = false },
                    onSubmitKyc = { submission ->
                        showKycDialog = false
                        viewModel.submitKyc(submission)
                    }
                )
            }

            // Compliance Dialog
            if (showComplianceDialog) {
                ComplianceDialog(onDismiss = { showComplianceDialog = false })
            }

            // Notifications Dialog
            if (showNotificationsDialog) {
                AlertDialog(
                    onDismissRequest = { showNotificationsDialog = false },
                    title = {
                        Text("Notifications & Alerts", color = EsportsCyan, fontWeight = FontWeight.Bold)
                    },
                    text = {
                        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                            if (notifications.isEmpty()) {
                                Text("No new notifications.", color = TextSecondary)
                            } else {
                                notifications.forEach { notif ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = EsportsSurfaceVariant,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(text = notif.title, fontWeight = FontWeight.Bold, color = TextPrimary)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(text = notif.message, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showNotificationsDialog = false }) {
                            Text("CLOSE", color = EsportsCyan)
                        }
                    },
                    containerColor = EsportsSurface,
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }
    }
}
