package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.navigation.AdityaBattleNav
import com.example.ui.theme.AdityaBattleTheme
import com.example.ui.theme.EsportsDarkBackground
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModelFactory((application as AdityaBattleApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AdityaBattleTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = EsportsDarkBackground
                ) {
                    AdityaBattleNav(viewModel = viewModel)
                }
            }
        }
    }
}
