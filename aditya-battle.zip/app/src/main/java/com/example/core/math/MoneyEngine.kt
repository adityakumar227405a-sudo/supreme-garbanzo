package com.example.core.math

/**
 * Money Engine for Aditya Battle.
 * All calculations use integer paise (Long) to ensure 100% precision.
 * ₹1 = 100 paise, ₹100 = 10,000 paise.
 */
object MoneyEngine {

    val PRESET_FEES_RUPEES: List<Long> = listOf(
        5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100,
        150, 200, 250, 300, 400, 500, 600, 700, 800, 900,
        1000, 1500, 2000, 2500, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000
    )

    const val MIN_ENTRY_FEE_RUPEES: Long = 5
    const val MAX_ENTRY_FEE_RUPEES: Long = 10000

    fun rupeesToPaise(rupees: Long): Long = rupees * 100L
    fun paiseToRupees(paise: Long): Double = paise / 100.0
    fun formatRupees(paise: Long): String {
        val rupees = paise / 100
        val remainingPaise = paise % 100
        return if (remainingPaise == 0L) {
            "₹$rupees"
        } else {
            "₹$rupees.${remainingPaise.toString().padStart(2, '0')}"
        }
    }

    /**
     * Platform Share Percentage rule:
     * Entry Fee ₹1 - ₹100: Platform 15%, Prize Pool 85%
     * Entry Fee ₹101 - ₹10,000: Platform 20%, Prize Pool 80%
     */
    fun getPlatformSharePercent(entryFeePaise: Long): Int {
        val entryFeeRupees = entryFeePaise / 100L
        return when {
            entryFeeRupees <= 0 -> 0
            entryFeeRupees in 1..100 -> 15
            else -> 20
        }
    }

    fun getPrizePoolPercent(entryFeePaise: Long): Int {
        val platformShare = getPlatformSharePercent(entryFeePaise)
        return if (entryFeePaise <= 0) 100 else 100 - platformShare
    }

    data class FinancialCalculation(
        val entryFeePaise: Long,
        val participants: Int,
        val grossPoolPaise: Long,
        val platformSharePercent: Int,
        val platformSharePaise: Long,
        val prizePoolPercent: Int,
        val prizePoolPaise: Long,
        val rankPrizesPaise: List<RankPrizePaise>
    )

    data class RankPrizePaise(
        val rank: Int,
        val rankLabel: String,
        val percentage: Double,
        val prizePaise: Long
    )

    /**
     * Calculates Gross Pool, Platform Share, Prize Pool, and Rank Distribution atomically.
     * Guaranteed: grossPoolPaise == platformSharePaise + prizePoolPaise
     * Guaranteed: sum(rankPrizes) == prizePoolPaise
     */
    fun calculateDistribution(
        entryFeePaise: Long,
        participants: Int,
        customRankRatios: List<Double>? = null
    ): FinancialCalculation {
        if (participants <= 0 || entryFeePaise <= 0) {
            return FinancialCalculation(
                entryFeePaise = entryFeePaise,
                participants = participants,
                grossPoolPaise = 0L,
                platformSharePercent = 0,
                platformSharePaise = 0L,
                prizePoolPercent = 100,
                prizePoolPaise = 0L,
                rankPrizesPaise = emptyList()
            )
        }

        val grossPoolPaise = participants.toLong() * entryFeePaise
        val platformPercent = getPlatformSharePercent(entryFeePaise)
        val platformSharePaise = (grossPoolPaise * platformPercent) / 100L
        val prizePoolPaise = grossPoolPaise - platformSharePaise

        // Default Rank distribution ratios: Rank 1 (50%), Rank 2 (30%), Rank 3 (15%), Rank 4 (5%)
        val ratios = customRankRatios ?: when {
            participants >= 60 -> listOf(0.40, 0.25, 0.15, 0.08, 0.04, 0.04, 0.02, 0.02) // Top 8
            participants >= 20 -> listOf(0.50, 0.30, 0.15, 0.05) // Top 4
            participants >= 10 -> listOf(0.60, 0.30, 0.10) // Top 3
            participants >= 2 -> listOf(0.70, 0.30) // Top 2
            else -> listOf(1.0) // Winner takes all
        }

        var distributedPaise = 0L
        val rankPrizes = mutableListOf<RankPrizePaise>()

        for (i in ratios.indices) {
            val ratio = ratios[i]
            val rankNum = i + 1
            val rawPrize = (prizePoolPaise * ratio).toLong()
            rankPrizes.add(
                RankPrizePaise(
                    rank = rankNum,
                    rankLabel = "Rank $rankNum",
                    percentage = ratio * 100.0,
                    prizePaise = rawPrize
                )
            )
            distributedPaise += rawPrize
        }

        // Remainder adjustment to ensure exact sum matches prizePoolPaise
        val remainder = prizePoolPaise - distributedPaise
        if (remainder != 0L && rankPrizes.isNotEmpty()) {
            val first = rankPrizes[0]
            rankPrizes[0] = first.copy(prizePaise = first.prizePaise + remainder)
        }

        return FinancialCalculation(
            entryFeePaise = entryFeePaise,
            participants = participants,
            grossPoolPaise = grossPoolPaise,
            platformSharePercent = platformPercent,
            platformSharePaise = platformSharePaise,
            prizePoolPercent = 100 - platformPercent,
            prizePoolPaise = prizePoolPaise,
            rankPrizesPaise = rankPrizes
        )
    }

    /**
     * Validates paid tournament entry fee against platform constraints
     */
    fun isValidPaidEntryFee(entryFeePaise: Long): Boolean {
        val rupees = entryFeePaise / 100L
        return rupees in MIN_ENTRY_FEE_RUPEES..MAX_ENTRY_FEE_RUPEES
    }
}
