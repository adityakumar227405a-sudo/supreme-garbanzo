package com.example.core.model

import androidx.annotation.DrawableRes
import com.example.R

enum class UserRole {
    USER,
    ADMIN
}

enum class KycStatus {
    NOT_SUBMITTED,
    PENDING,
    VERIFIED,
    REJECTED
}

enum class TournamentCategory(val displayName: String, val iconName: String) {
    BATTLE_ROYALE("Battle Royale", "ic_br"),
    CLASH_SQUAD("Clash Squad", "ic_cs"),
    LONE_WOLF("Lone Wolf", "ic_lw"),
    DUO("Duo Tournament", "ic_duo"),
    SQUAD("Squad Tournament", "ic_squad"),
    CS_RANKED("CS Ranked", "ic_ranked"),
    GUILD("Guild War", "ic_guild"),
    CUSTOM("Custom Room", "ic_custom"),
    CRAFTLAND("Craftland Arena", "ic_craftland"),
    CHALLENGE("Challenge Mode", "ic_challenge")
}

enum class TournamentStatus(val label: String) {
    OPEN("Open"),
    FULL("Full"),
    UPCOMING("Upcoming"),
    LIVE("Live"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

enum class MatchFormat(val label: String) {
    SOLO("Solo (1vAll)"),
    DUO("Duo (2v2)"),
    SQUAD("Squad (4v4)"),
    CLASH_4V4("Clash 4v4"),
    CLASH_1V1("Clash 1v1"),
    CLASH_2V2("Clash 2v2"),
    LONE_WOLF_1V1("Lone Wolf 1v1"),
    LONE_WOLF_2V2("Lone Wolf 2v2"),
    TRIO("Trio (3v3)"),
    TEAM_5V5("5v5 Custom"),
    CUSTOM_SIZE("Custom Team Size")
}

enum class TournamentFormatType(val label: String, val description: String) {
    SINGLE_MATCH("Single Match", "1 Decisive match determines winners"),
    BEST_OF_1("Best of 1", "Single match high stakes"),
    BEST_OF_3("Best of 3", "3 Rounds series - highest points"),
    BEST_OF_5("Best of 5", "5 Rounds championship"),
    KNOCKOUT("Knockout", "Single elimination bracket"),
    LEAGUE("League / Points Table", "Cumulative standings table"),
    ROUND_ROBIN("Round Robin", "Every team faces all opponents"),
    QUALIFIER("Qualifier Round", "Top teams advance to finals"),
    SEMI_FINAL("Semi Final", "Penultimate clash round"),
    GRAND_FINAL("Grand Final", "Championship grand finale")
}

enum class TournamentTierType(val label: String, val feeRange: String) {
    FREE("Free Tournament", "₹0 Entry"),
    LOW_ENTRY("Low Entry (Pocket)", "₹5 – ₹100"),
    MEDIUM_ENTRY("Popular / Mid Stakes", "₹101 – ₹1,000"),
    HIGH_ENTRY("High Roller", "₹1,001 – ₹10,000"),
    MEGA_CHAMPIONSHIP("Mega Championship", "Grand Prize Pool")
}

enum class TournamentDifficulty(
    val displayName: String,
    val shortTag: String,
    val description: String,
    val badgeColorHex: Long = 0xFF00E5FF
) {
    EASY("Easy", "EASY", "Budget friendly & Beginner friendly (₹5 / ₹10)", 0xFF00E676),
    MEDIUM("Medium", "MEDIUM", "Competitive Daily Clashes (₹10 / ₹20)", 0xFFFFD700),
    HARD("Hard", "HARD", "Pro Level High Stakes (₹20 / ₹50)", 0xFFFF2A6D),
    NORMAL("Normal", "NORMAL", "Standard Classic Battle (₹10 / ₹30)", 0xFF00E5FF),
    MEGA("Mega", "MEGA", "Grand High-Stakes Championship (₹100+)", 0xFFBD00FF)
}

enum class RoomType(val label: String) {
    CLASSIC_BERMUDA("Bermuda Classic"),
    PURGATORY("Purgatory"),
    KALAHARI("Kalahari"),
    ALPINE("Alpine"),
    NEXTERRA("NexTerra"),
    IRON_CAGE("Iron Cage (1v1)"),
    FACTORY_ROOF("Factory Roof"),
    CUSTOM_MAP("Custom Arena"),
    TRAINING_ISLAND("Training Grounds")
}

// Configurable Game Mode Entity
data class ConfigurableGameMode(
    val id: String,
    val name: String,
    val parentCategory: TournamentCategory,
    val isRanked: Boolean = false,
    val defaultMatchFormat: MatchFormat = MatchFormat.SQUAD,
    val isEnabled: Boolean = true,
    val description: String = ""
)

// Configurable Map Entity
data class ConfigurableGameMap(
    val id: String,
    val name: String,
    val modeCategory: TournamentCategory,
    val roomType: RoomType,
    val isEnabled: Boolean = true,
    val supportedFormats: List<MatchFormat> = listOf(MatchFormat.SOLO, MatchFormat.DUO, MatchFormat.SQUAD),
    val minPlayers: Int = 2,
    val maxPlayers: Int = 48,
    val description: String = "",
    @DrawableRes val customImageRes: Int? = null
)

// Configurable Scoring Rules
data class ScoringConfig(
    val placementPoints: Map<Int, Int> = mapOf(
        1 to 12,
        2 to 9,
        3 to 8,
        4 to 7,
        5 to 6,
        6 to 5,
        7 to 4,
        8 to 3,
        9 to 2,
        10 to 1
    ),
    val killPoints: Int = 1,
    val assistPoints: Int = 0,
    val survivalPointsPerMin: Int = 0,
    val bonusPoints: Int = 0,
    val winPoints: Int = 0
) {
    fun calculateTotal(placement: Int, kills: Int, assists: Int = 0, survivalMins: Int = 0, bonus: Int = 0): Int {
        val placePts = placementPoints[placement] ?: 0
        val killPts = kills * killPoints
        val assistPts = assists * assistPoints
        val survPts = survivalMins * survivalPointsPerMin
        return placePts + killPts + assistPts + survPts + bonus + bonusPoints
    }
}

enum class TransactionType(val label: String, val isCredit: Boolean) {
    DEPOSIT("Deposit Added", true),
    TOURNAMENT_ENTRY("Tournament Entry Fee", false),
    TOURNAMENT_REWARD("Tournament Prize Won", true),
    REFUND("Tournament Refund", true),
    WITHDRAWAL("Withdrawal Payout", false),
    BONUS("Promotional Reward", true),
    ADMIN_ADJUSTMENT("Admin Adjustment", true)
}

enum class TransactionStatus {
    COMPLETED,
    PENDING,
    FAILED
}

enum class PaymentMethod(val displayName: String, val iconDescription: String) {
    UPI_GPAY("Google Pay UPI", "GPay Instant Transfer"),
    UPI_PHONEPE("PhonePe UPI", "PhonePe Fast Pay"),
    UPI_PAYTM("Paytm UPI / Wallet", "Paytm Gateway"),
    UPI_CUSTOM("Any UPI App (BHIM/Cred)", "VPA Handle"),
    DEBIT_CARD("Debit / Credit Card", "Visa, Mastercard, RuPay"),
    NET_BANKING("Net Banking", "Instant IMPS Bank Transfer")
}

enum class WithdrawalMethod(val displayName: String) {
    UPI("Instant UPI Transfer"),
    BANK_ACCOUNT("Direct IMPS Bank Transfer")
}

data class UserProfile(
    val id: String,
    val username: String,
    val email: String,
    val mobileNumber: String,
    val inGameName: String = "ShadowHunter",
    val inGameId: String = "84920481",
    val avatarUrl: String = "",
    val role: UserRole = UserRole.USER,
    val kycStatus: KycStatus = KycStatus.VERIFIED,
    val referralCode: String = "ADITYA77",
    val referredBy: String? = null,
    val totalTournaments: Int = 18,
    val totalWins: Int = 7,
    val totalKills: Int = 94,
    val isSuspended: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class WalletState(
    val userId: String,
    val depositBalancePaise: Long = 50000L, // ₹500
    val winningWithdrawablePaise: Long = 125000L, // ₹1,250
    val pendingHoldPaise: Long = 0L,
    val coinBalance: Long = 850L // Separate non-withdrawable coins
) {
    val totalBalancePaise: Long
        get() = depositBalancePaise + winningWithdrawablePaise
}

data class WalletTransactionRecord(
    val id: String,
    val userId: String,
    val type: TransactionType,
    val amountPaise: Long,
    val balanceAfterPaise: Long,
    val description: String,
    val referenceId: String,
    val status: TransactionStatus = TransactionStatus.COMPLETED,
    val timestamp: Long = System.currentTimeMillis(),
    val tournamentTitle: String? = null
)

data class TournamentItem(
    val id: String,
    val title: String,
    val category: TournamentCategory,
    val entryFeePaise: Long, // 0 for Free, 500..1000000 for Paid
    val maxSlots: Int,
    val filledSlots: Int,
    val matchFormat: MatchFormat,
    val mapName: RoomType,
    val scheduledTimeEpoch: Long,
    val status: TournamentStatus,
    val roomId: String = "",
    val roomPassword: String = "",
    val roomReleaseTime: String = "15 mins before match",
    val description: String,
    val rules: List<String>,
    val killPointRewardPaise: Long = 1000L, // ₹10 per kill
    val difficulty: TournamentDifficulty = TournamentDifficulty.NORMAL,
    @DrawableRes val customBannerRes: Int? = null,
    val isJoined: Boolean = false,
    val formatType: TournamentFormatType = TournamentFormatType.SINGLE_MATCH,
    val tierType: TournamentTierType = TournamentTierType.LOW_ENTRY,
    val scoringConfig: ScoringConfig = ScoringConfig(),
    val gameModeName: String = category.displayName
) {
    val remainingSlots: Int
        get() = (maxSlots - filledSlots).coerceAtLeast(0)
    val isFull: Boolean
        get() = filledSlots >= maxSlots
    val isFree: Boolean
        get() = entryFeePaise == 0L
    val isPocketTournament: Boolean
        get() = entryFeePaise in 500L..10000L // ₹5 - ₹100
}

data class ParticipantRecord(
    val id: String,
    val tournamentId: String,
    val userId: String,
    val username: String,
    val inGameName: String,
    val inGameId: String,
    val entryFeePaise: Long,
    val transactionId: String,
    val slotNumber: Int,
    val joinedAt: Long = System.currentTimeMillis()
)

data class MatchResultRecord(
    val id: String,
    val tournamentId: String,
    val userId: String,
    val username: String,
    val inGameName: String,
    val kills: Int,
    val placement: Int,
    val killPoints: Int,
    val placementPoints: Int,
    val bonusPoints: Int,
    val totalPoints: Int,
    val rank: Int,
    val prizePaise: Long,
    val isFinalized: Boolean = true
)

data class HomeBanner(
    val id: String,
    val title: String,
    val subtitle: String,
    val tag: String,
    @DrawableRes val imageRes: Int,
    val targetCategory: TournamentCategory? = null
)

data class DailyTaskItem(
    val id: String,
    val title: String,
    val description: String,
    val rewardCoins: Long,
    val currentProgress: Int,
    val maxProgress: Int,
    val isClaimed: Boolean = false
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val type: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class KycSubmission(
    val fullName: String,
    val dateOfBirth: String,
    val panNumber: String,
    val aadharLast4: String,
    val upiId: String,
    val bankAccountNumber: String,
    val ifscCode: String,
    val state: String
)

data class WithdrawalRecord(
    val id: String,
    val userId: String,
    val amountPaise: Long,
    val method: WithdrawalMethod,
    val destination: String,
    val status: TransactionStatus,
    val requestedAt: Long = System.currentTimeMillis(),
    val processedAt: Long? = null
)

data class AuditLogEntry(
    val id: String,
    val adminName: String,
    val action: String,
    val target: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
