package com.example

import android.app.Application
import com.example.data.repository.EsportsRepository

class AdityaBattleApp : Application() {

    lateinit var repository: EsportsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = EsportsRepository(this)
    }
}
