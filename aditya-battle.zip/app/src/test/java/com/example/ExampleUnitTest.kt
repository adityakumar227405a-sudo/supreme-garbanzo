package com.example

import com.example.core.math.MoneyEngine
import com.example.core.model.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testMoneyEngine_tierPercentages_lowFeeTier() {
    val lowFees = listOf(1L, 5L, 10L, 20L, 30L, 50L, 99L, 100L)
    for (rupees in lowFees) {
      val feePaise = MoneyEngine.rupeesToPaise(rupees)
      val calc = MoneyEngine.calculateDistribution(entryFeePaise = feePaise, participants = 48)
      assertEquals("Fee ₹$rupees should have 15% platform share", 15, calc.platformSharePercent)
      assertEquals("Fee ₹$rupees should have 85% prize pool", 85, calc.prizePoolPercent)
      assertEquals("Conservation of funds for fee ₹$rupees", calc.grossPoolPaise, calc.platformSharePaise + calc.prizePoolPaise)
      val rankSum = calc.rankPrizesPaise.sumOf { it.prizePaise }
      assertEquals("Rank prizes sum must equal prize pool for fee ₹$rupees", calc.prizePoolPaise, rankSum)
    }
  }

  @Test
  fun testMoneyEngine_tierPercentages_highFeeTier() {
    val highFees = listOf(101L, 200L, 500L, 1000L, 2500L, 5000L, 10000L)
    for (rupees in highFees) {
      val feePaise = MoneyEngine.rupeesToPaise(rupees)
      val calc = MoneyEngine.calculateDistribution(entryFeePaise = feePaise, participants = 100)
      assertEquals("Fee ₹$rupees should have 20% platform share", 20, calc.platformSharePercent)
      assertEquals("Fee ₹$rupees should have 80% prize pool", 80, calc.prizePoolPercent)
      assertEquals("Conservation of funds for fee ₹$rupees", calc.grossPoolPaise, calc.platformSharePaise + calc.prizePoolPaise)
      val rankSum = calc.rankPrizesPaise.sumOf { it.prizePaise }
      assertEquals("Rank prizes sum must equal prize pool for fee ₹$rupees", calc.prizePoolPaise, rankSum)
    }
  }

  @Test
  fun testMoneyEngine_freeTournaments() {
    val calc = MoneyEngine.calculateDistribution(entryFeePaise = 0L, participants = 48)
    assertEquals(0L, calc.grossPoolPaise)
    assertEquals(0L, calc.prizePoolPaise)
    assertEquals(0L, calc.platformSharePaise)
  }

  @Test
  fun testConfigurableModesAndMaps() {
    val mode = ConfigurableGameMode(
      id = "cs_4v4",
      name = "Clash Squad 4v4",
      parentCategory = TournamentCategory.CLASH_SQUAD,
      defaultMatchFormat = MatchFormat.CLASH_4V4
    )
    val map = ConfigurableGameMap(
      id = "map_bermuda",
      name = "Bermuda Classic",
      modeCategory = TournamentCategory.BATTLE_ROYALE,
      roomType = RoomType.CLASSIC_BERMUDA
    )

    assertTrue(mode.isEnabled)
    assertTrue(map.isEnabled)
    assertEquals("Clash Squad 4v4", mode.name)
    assertEquals("Bermuda Classic", map.name)
  }
}
